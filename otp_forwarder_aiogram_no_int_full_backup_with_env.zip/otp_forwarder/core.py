"""Core business logic for the aiogram OTP forwarder."""
from __future__ import annotations

import asyncio
import html
import logging
import os
import zipfile
from pathlib import Path
from datetime import datetime
from typing import Any

import httpx
from aiogram import Bot
from aiogram.types import FSInputFile, InlineKeyboardMarkup, InputRichMessage
from cachetools import TTLCache

from .bot.menus import otp_keyboard, traffic_keyboard, traffic_message
from .config import settings
from .database import Database
from .fetchers.legacy import fetch_legacy as fetch_legacy_async
from .fetchers.numberpanel import fetch_numberpanel as fetch_numberpanel_async
from .utils.country import get_country_info
from .utils.models import OTPEntry
from .utils.otp import detect_service, extract_otp, mask_number

logger = logging.getLogger(__name__)

BOT_TOKEN = settings.bot_token
DEFAULT_GROUP_ID = settings.default_group_id
OWNER_ID = settings.owner_id
YOUR_BOT_NAME = settings.bot_name
API_KEY = settings.api_key
BASE_URL = settings.base_url
LEGACY_URL = settings.legacy_url
LEGACY_TOKEN = settings.legacy_token
SCAN_INTERVAL = settings.scan_interval
REQUEST_TIMEOUT = settings.request_timeout
CACHE_MAX_SIZE = settings.cache_max_size
DB_PATH = settings.db_path
PACKAGE_DIR = Path(__file__).resolve().parent

BROADCAST_SEMAPHORE = asyncio.Semaphore(15)
SEEN_OTPS: TTLCache[str, bool] = TTLCache(maxsize=CACHE_MAX_SIZE, ttl=86400)
START_TIME = datetime.now()
db = Database(DB_PATH, default_group_id=DEFAULT_GROUP_ID)


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"},
        timeout=REQUEST_TIMEOUT,
        follow_redirects=True,
    )


async def fetch_numberpanel(client: httpx.AsyncClient | None = None) -> list[dict[str, Any]]:
    """Fetch OTP records from the documented endpoints used by the legacy bot."""
    owned = client is None
    active_client = client or _client()
    try:
        return await fetch_numberpanel_async(
            active_client,
            base_url=BASE_URL,
            api_key=API_KEY,
            timeout=REQUEST_TIMEOUT,
        )
    finally:
        if owned:
            await active_client.aclose()


async def fetch_legacy(client: httpx.AsyncClient | None = None) -> list[dict[str, Any]]:
    """Fetch records from the legacy API endpoint."""
    if not LEGACY_URL:
        return []
    owned = client is None
    active_client = client or _client()
    try:
        return await fetch_legacy_async(
            active_client,
            url=LEGACY_URL,
            token=LEGACY_TOKEN,
            timeout=REQUEST_TIMEOUT,
        )
    finally:
        if owned:
            await active_client.aclose()


async def fetch_all(client: httpx.AsyncClient | None = None) -> list[dict[str, Any]]:
    """Fetch every configured source concurrently and remove duplicate records."""
    owned = client is None
    active_client = client or _client()
    try:
        results = await asyncio.gather(
            fetch_numberpanel(active_client),
            fetch_legacy(active_client),
            return_exceptions=True,
        )
        combined: list[dict[str, Any]] = []
        for result in results:
            if isinstance(result, Exception):
                logger.error("Fetcher cycle failed: %s", result, exc_info=result)
                continue
            combined.extend(result)
        unique: dict[str, dict[str, Any]] = {}
        for entry in combined:
            key = f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}"
            unique.setdefault(key, entry)
        return sorted(unique.values(), key=lambda item: str(item.get("timestamp", "")), reverse=True)
    finally:
        if owned:
            await active_client.aclose()


async def fetch_all_resend_sources() -> list[dict[str, Any]]:
    """Combine current API records with persisted records for /resend."""
    api_entries = await fetch_all()
    db_entries = db.get_all_otps()
    unique: dict[str, dict[str, Any]] = {}
    for entry in api_entries + db_entries:
        key = f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}"
        unique.setdefault(key, entry)
    return sorted(unique.values(), key=lambda item: str(item.get("timestamp", "")), reverse=True)


def format_otp_message(entry: dict[str, Any]) -> tuple[str, InlineKeyboardMarkup]:
    """Build the backward-compatible HTML OTP representation."""
    service = str(entry.get("service") or "Unknown")
    text = str(entry.get("text") or "")
    phone = str(entry.get("phone") or "")
    source = str(entry.get("source") or "")
    if service in {"Unknown", "SMS"}:
        detected = detect_service(text)
        if detected != "Unknown":
            service = detected
    country, flag, iso, carrier = get_country_info(phone)
    otp = str(entry.get("otp_code") or extract_otp(text) or "N/A")
    body = (
        "<b>⚡ NEW OTP RECEIVED</b>\n"
        f"🌐 <b>Service:</b> {html.escape(service)}\n"
        f"{flag} <b>Country:</b> {html.escape(country)} ({html.escape(iso)})\n"
        f"📱 <b>Number:</b> <code>{html.escape(mask_number(phone))}</code>\n"
        f"📡 <b>Carrier:</b> <code>{html.escape(carrier)}</code>\n"
        f"📥 <b>Source:</b> {html.escape(source)}\n"
        f"🔑 <b>Verification Code:</b> <code>{html.escape(otp)}</code>"
    )
    return body, otp_keyboard(otp)


def format_otp_rich_message(entry: dict[str, Any]) -> tuple[InputRichMessage, InlineKeyboardMarkup]:
    """Build the native Rich Message OTP representation."""
    service = str(entry.get("service") or "Unknown")
    text = str(entry.get("text") or "")
    phone = str(entry.get("phone") or "")
    source = str(entry.get("source") or "")
    if service in {"Unknown", "SMS"}:
        detected = detect_service(text)
        if detected != "Unknown":
            service = detected
    country, flag, iso, carrier = get_country_info(phone)
    otp = str(entry.get("otp_code") or extract_otp(text) or "N/A")
    from aiogram.types import InputRichBlockParagraph, InputRichBlockPreformatted, InputRichBlockSectionHeading, InputRichBlockTable, RichBlockTableCell

    cells = [
        [RichBlockTableCell(align="left", valign="middle", text="Service", is_header=True), RichBlockTableCell(align="left", valign="middle", text=service)],
        [RichBlockTableCell(align="left", valign="middle", text="Country", is_header=True), RichBlockTableCell(align="left", valign="middle", text=f"{flag} {country} ({iso})")],
        [RichBlockTableCell(align="left", valign="middle", text="Number", is_header=True), RichBlockTableCell(align="left", valign="middle", text=mask_number(phone))],
        [RichBlockTableCell(align="left", valign="middle", text="Carrier", is_header=True), RichBlockTableCell(align="left", valign="middle", text=carrier)],
        [RichBlockTableCell(align="left", valign="middle", text="Source", is_header=True), RichBlockTableCell(align="left", valign="middle", text=source)],
    ]
    rich = InputRichMessage(
        blocks=[
            InputRichBlockSectionHeading(text="⚡ NEW OTP RECEIVED", size=1),
            InputRichBlockParagraph(text="A new verification message was detected."),
            InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True, is_compact=True),
            InputRichBlockParagraph(text="🔑 Verification Code"),
            InputRichBlockPreformatted(text=otp),
        ]
    )
    return rich, otp_keyboard(otp)


async def broadcast_to_groups(
    bot: Bot,
    rich_message: InputRichMessage,
    markup: InlineKeyboardMarkup | None = None,
    auto_pin: bool = False,
) -> int:
    """Broadcast a rich message and return the number of successful deliveries."""
    sent_count = 0
    async with BROADCAST_SEMAPHORE:
        for chat_id, _title in db.get_groups():
            try:
                sent = await bot.send_rich_message(
                    chat_id=chat_id,
                    rich_message=rich_message,
                    reply_markup=markup,
                    disable_notification=False,
                )
                sent_count += 1
                if auto_pin:
                    try:
                        await bot.pin_chat_message(
                            chat_id=chat_id,
                            message_id=sent.message_id,
                            disable_notification=True,
                        )
                    except Exception as exc:
                        logger.error("Could not pin message in group %s: %s", chat_id, exc)
            except Exception as exc:
                logger.error("Rich broadcast error for group %s: %s", chat_id, exc)
    return sent_count


async def send_to_group(bot: Bot, entry: dict[str, Any]) -> bool:
    """Send an OTP record to configured groups."""
    rich, markup = format_otp_rich_message(entry)
    return await broadcast_to_groups(bot, rich, markup=markup, auto_pin=False) > 0


async def create_and_send_backup(bot: Bot, chat_id: int) -> bool:
    """Create a complete safe project backup and deliver it to a Telegram chat."""
    filename = Path.cwd() / f"otp_bot_backup_{datetime.now():%Y%m%d_%H%M%S}.zip"
    project_root = PACKAGE_DIR.parent
    excluded_dirs = {"__pycache__", ".pytest_cache", ".git", "venv", ".venv"}
    excluded_names: set[str] = set()
    try:
        with zipfile.ZipFile(filename, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in project_root.rglob("*"):
                if not path.is_file():
                    continue
                relative = path.relative_to(project_root)
                if any(part in excluded_dirs for part in relative.parts):
                    continue
                if path.name in excluded_names:
                    continue
                if path.resolve() == filename.resolve():
                    continue
                archive.write(path, arcname=str(relative).replace("\\", "/"))

        await bot.send_document(
            chat_id=chat_id,
            document=FSInputFile(str(filename)),
            caption=(
                "<b>📦 COMPLETE SYSTEM BACKUP</b>\n"
                "Contains source code, configuration, tests, documentation, SQLite database, "
                "and the live .env file. Keep this archive private.\n"
                f"Timestamp: <code>{datetime.now():%Y-%m-%d %H:%M:%S}</code>"
            ),
            parse_mode="HTML",
        )
        return True
    except Exception as exc:
        logger.exception("Backup generation error: %s", exc)
        return False
    finally:
        if filename.exists():
            filename.unlink()


async def run_scanner(bot: Bot) -> None:
    """Continuously scan configured sources and broadcast new OTP records."""
    global SEEN_OTPS
    async with _client() as client:
        try:
            initial = await fetch_all(client)
            for entry in initial[:500]:
                SEEN_OTPS[OTPEntry.model_validate(entry).key()] = True
            logger.info("Loaded %d initial OTP records into cache", len(SEEN_OTPS))
        except Exception as exc:
            logger.error("Initial scanner load failed: %s", exc, exc_info=True)

        while True:
            try:
                entries = await fetch_all(client)
                dispatched = 0
                for entry in entries:
                    normalized = OTPEntry.model_validate(entry)
                    key = normalized.key()
                    if key in SEEN_OTPS:
                        continue
                    otp = normalized.otp_code or extract_otp(normalized.text)
                    if not otp:
                        continue
                    normalized.otp_code = otp
                    country, flag, iso, carrier = get_country_info(normalized.phone)
                    normalized.country = country
                    normalized.flag = flag
                    normalized.country_code = iso
                    normalized.carrier = carrier
                    if normalized.service in {"Unknown", "SMS"}:
                        detected = detect_service(normalized.text)
                        if detected != "Unknown":
                            normalized.service = detected
                    entry_data = normalized.as_dict()
                    db.save_otp(entry_data)
                    if await send_to_group(bot, entry_data):
                        SEEN_OTPS[key] = True
                        dispatched += 1
                        logger.info(
                            "Sent OTP %s | %s | %s",
                            otp,
                            mask_number(normalized.phone),
                            normalized.service,
                        )
                if dispatched:
                    logger.info("Dispatched %d new OTP notifications", dispatched)
            except asyncio.CancelledError:
                logger.info("Scanner task cancelled")
                raise
            except Exception as exc:
                logger.error("Scanner cycle failed: %s", exc, exc_info=True)
            await asyncio.sleep(SCAN_INTERVAL)


async def run_traffic_poster(bot: Bot) -> None:
    """Publish and pin the 30-minute traffic report every 30 minutes."""
    while True:
        try:
            await asyncio.sleep(1800)
            data = db.get_live_traffic_30m()
            if data:
                rich = traffic_message()
                sent = await broadcast_to_groups(bot, rich, traffic_keyboard(), auto_pin=True)
                logger.info("Auto-traffic report delivered to %d groups", sent)
        except asyncio.CancelledError:
            logger.info("Traffic poster task cancelled")
            raise
        except Exception as exc:
            logger.error("Auto-traffic poster failed: %s", exc, exc_info=True)


async def run_hourly_backup(bot: Bot) -> None:
    """Send the database/source backup to the configured owner every hour."""
    while True:
        try:
            await asyncio.sleep(3600)
            logger.info("Triggering hourly automated system backup")
            success = await create_and_send_backup(bot, OWNER_ID)
            logger.info("Hourly backup result: %s", success)
        except asyncio.CancelledError:
            logger.info("Hourly backup task cancelled")
            raise
        except Exception as exc:
            logger.error("Hourly automated backup failed: %s", exc, exc_info=True)
