# Known Issues / Verification Boundaries

## Endpoint liveness is unverified

The NumberPanel and Legacy endpoint values were recovered from the legacy project source, but the build environment could not perform reliable live network verification. They may be unavailable, changed, rate-limited, or require credentials/cookies that are no longer valid.

## Dependency verification is pending

`requirements.txt` pins compatible major-version ranges, including aiogram 3.31+, httpx, pydantic 2.x, cachetools, tenacity, pytest, ruff, and mypy. A complete `pip install -r requirements.txt` could not be verified in the build environment because external package/DNS access was unavailable.

The exact locally resolved versions should therefore be recorded after installation.

## Runtime-sensitive areas

1. **aiogram Rich Messages** — the project uses native Rich Message types and methods. Runtime compatibility depends on the installed aiogram version satisfying the requirement.
2. **External fetchers** — endpoint response formats and authentication can change independently of this code.
3. **Telegram permissions** — group sending/pinning depends on the bot's actual permissions.
4. **`.env` values** — invalid IDs, tokens, cookies, or API keys can prevent startup or fetches.
5. **SQLite file permissions** — the process needs write access to the configured database path.
6. **Backup source/database paths** — backup creation now resolves the preserved legacy source relative to the package and resolves relative DB paths relative to the package, while the temporary ZIP is created in the current working directory.
7. **Live polling** — no real Telegram bot token was available in the build environment, so polling was not started against Telegram.

## Fallback plan

If local verification finds a problem:

1. Keep the exact traceback/output.
2. Identify whether it is installation, import, lint/type, database, Telegram, or external-endpoint related.
3. Send the failing command plus the relevant output.
4. Patch only the affected component first; rerun the complete local verification set afterward.
5. Do not replace credentials/endpoints with invented values.

## Security note

This package contains `.env.example` placeholders only. Put real secrets in `.env`, keep `.env` out of source control, and rotate any credential that was previously exposed outside a private environment.
