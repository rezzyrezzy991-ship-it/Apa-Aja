"""Hourly backup task entry point."""
from ..core import run_hourly_backup
__all__ = ["run_hourly_backup"]
