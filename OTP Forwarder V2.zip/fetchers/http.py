"""Shared asynchronous HTTP helpers with retry and structured logging."""
from __future__ import annotations

from typing import Any

import httpx
from tenacity import AsyncRetrying, retry_if_exception, stop_after_attempt, wait_exponential

DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"}


def _retryable(exc: BaseException) -> bool:
    if isinstance(exc, (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError)):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code >= 500
    return False


async def request_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    timeout: float,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | None = None,
    data: dict[str, Any] | None = None,
) -> Any:
    """Request JSON with bounded exponential retry for transient failures."""
    merged = {**DEFAULT_HEADERS, **(headers or {})}
    async for attempt in AsyncRetrying(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.25, min=0.25, max=2),
        retry=retry_if_exception(_retryable),
        reraise=True,
    ):
        with attempt:
            response = await client.request(
                method,
                url,
                headers=merged,
                params=params,
                data=data,
                timeout=timeout,
            )
            response.raise_for_status()
            return response.json()
    raise RuntimeError("HTTP retry loop terminated unexpectedly")
