"""Inline keyboard compatibility exports for the Rich Message UI."""
from .menus import (
    main_keyboard,
    stats_keyboard,
    traffic_keyboard,
    groups_keyboard,
    settings_keyboard,
    search_keyboard,
    backup_keyboard,
)

__all__ = [
    "main_keyboard", "stats_keyboard", "traffic_keyboard", "groups_keyboard",
    "settings_keyboard", "search_keyboard", "backup_keyboard",
]
