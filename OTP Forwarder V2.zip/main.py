"""Application entry point for OTP Forwarder."""
from __future__ import annotations

if __package__ in {None, ""}:
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "otp_forwarder"

import asyncio
import logging
import signal
from datetime import datetime

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from . import core
from .bot.handlers import router
from .config import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def main() -> None:
    """Start polling and all background tasks until shutdown."""
    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dispatcher = Dispatcher()
    dispatcher.include_router(router)
    core.START_TIME = datetime.now()
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()

    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signum, stop_event.set)
        except Exception as exc:
            logger.debug("Signal handler unavailable for %s: %s", signum, exc)

    tasks: list[asyncio.Task[None]] = []
    polling_task: asyncio.Task[None] | None = None
    try:
        logger.info("Starting OTP Forwarder aiogram engine")
        tasks = [
            asyncio.create_task(core.run_scanner(bot), name="scanner"),
            asyncio.create_task(core.run_traffic_poster(bot), name="traffic-poster"),
            asyncio.create_task(core.run_hourly_backup(bot), name="hourly-backup"),
        ]
        polling_task = asyncio.create_task(dispatcher.start_polling(bot), name="telegram-polling")
        await stop_event.wait()
    finally:
        logger.info("Graceful shutdown requested")
        if polling_task is not None:
            polling_task.cancel()
            await asyncio.gather(polling_task, return_exceptions=True)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        await bot.session.close()
        logger.info("Engine stopped cleanly")


if __name__ == "__main__":
    asyncio.run(main())
