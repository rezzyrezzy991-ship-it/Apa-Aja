"""SQLite persistence layer for OTP Forwarder."""
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Dict, List, Tuple
import logging
import sqlite3

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    @contextmanager
    def _get_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=10000")
        try:
            yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("""CREATE TABLE IF NOT EXISTS otps (
                id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, text TEXT,
                service TEXT, source TEXT, timestamp TEXT, otp_code TEXT,
                country TEXT, country_code TEXT, carrier TEXT, flag TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP)""")
            cursor.execute("""CREATE TABLE IF NOT EXISTS target_groups (
                chat_id INTEGER PRIMARY KEY, title TEXT,
                added_at DATETIME DEFAULT CURRENT_TIMESTAMP)""")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_phone ON otps(phone)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_service ON otps(service)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_timestamp ON otps(timestamp)")
            # Preserve legacy behavior for a configured primary group on fresh installs.
            try:
                from .config import settings
                if settings.default_group_id:
                    cursor.execute("INSERT OR IGNORE INTO target_groups (chat_id, title) VALUES (?, ?)", (settings.default_group_id, "Primary Group"))
            except Exception:
                pass
            conn.commit()

    def add_group(self, chat_id: int, title: str) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute("INSERT OR REPLACE INTO target_groups (chat_id, title) VALUES (?, ?)", (chat_id, title))
                conn.commit()
                return True
        except Exception as exc:
            logger.error("Add Group DB Error: %s", exc)
            return False

    def remove_group(self, chat_id: int) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute("DELETE FROM target_groups WHERE chat_id = ?", (chat_id,))
                conn.commit()
                return True
        except Exception as exc:
            logger.error("Remove Group DB Error: %s", exc)
            return False

    def get_groups(self) -> List[Tuple[int, str]]:
        try:
            with self._get_conn() as conn:
                rows = conn.execute("SELECT chat_id, title FROM target_groups").fetchall()
                return [(int(row["chat_id"]), row["title"]) for row in rows]
        except Exception as exc:
            logger.error("Get groups DB Error: %s", exc)
            return []

    def save_otp(self, entry: Dict[str, Any]) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute("""INSERT INTO otps
                    (phone, text, service, source, timestamp, otp_code,
                     country, country_code, carrier, flag)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (entry.get("phone", ""), entry.get("text", ""),
                     entry.get("service", "Unknown"), entry.get("source", ""),
                     entry.get("timestamp", datetime.now().isoformat()),
                     entry.get("otp_code", ""), entry.get("country", ""),
                     entry.get("country_code", ""), entry.get("carrier", ""),
                     entry.get("flag", "")))
                conn.commit()
                return True
        except Exception as exc:
            logger.error("Save OTP DB Error: %s", exc)
            return False

    def get_all_otps(self) -> List[Dict[str, Any]]:
        with self._get_conn() as conn:
            rows = conn.execute("""SELECT phone,text,service,source,timestamp,otp_code,
                country,country_code,carrier,flag FROM otps ORDER BY id DESC""").fetchall()
            return [{
                "phone": r["phone"], "text": r["text"], "service": r["service"],
                "source": f"💾 DB ({r['source']})", "timestamp": r["timestamp"],
                "otp_code": r["otp_code"], "country": r["country"],
                "country_code": r["country_code"], "carrier": r["carrier"], "flag": r["flag"]
            } for r in rows]

    def get_stats(self) -> Dict[str, Any]:
        stats: Dict[str, Any] = {"total": 0, "by_source": {}, "by_service": {}, "by_country": {}, "last_hour": 0, "last_24h": 0}
        with self._get_conn() as conn:
            stats["total"] = conn.execute("SELECT COUNT(*) FROM otps").fetchone()[0]
            for row in conn.execute("SELECT source,COUNT(*) count FROM otps GROUP BY source ORDER BY count DESC"):
                stats["by_source"][row["source"]] = row["count"]
            for row in conn.execute("SELECT service,COUNT(*) count FROM otps WHERE service!='Unknown' GROUP BY service ORDER BY count DESC LIMIT 20"):
                stats["by_service"][row["service"]] = row["count"]
            for row in conn.execute("SELECT country_code,COUNT(*) count FROM otps WHERE country_code!='UN' GROUP BY country_code ORDER BY count DESC LIMIT 20"):
                stats["by_country"][row["country_code"]] = row["count"]
            stats["last_hour"] = conn.execute("SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-1 hour')").fetchone()[0]
            stats["last_24h"] = conn.execute("SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-24 hours')").fetchone()[0]
        return stats

    def get_live_traffic_30m(self):
        with self._get_conn() as conn:
            total = conn.execute("SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-30 minutes')").fetchone()[0]
            if total == 0:
                return None
            countries = conn.execute("""SELECT country,country_code,flag,COUNT(*) count FROM otps
                WHERE created_at >= datetime('now','-30 minutes') AND country_code!='UN'
                GROUP BY country_code ORDER BY count DESC LIMIT 5""").fetchall()
            services = conn.execute("""SELECT service,COUNT(*) count FROM otps
                WHERE created_at >= datetime('now','-30 minutes') AND service!='Unknown'
                GROUP BY service ORDER BY count DESC LIMIT 3""").fetchall()
            return total, countries, services

    def search_by_service(self, service: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self._get_conn() as conn:
            rows = conn.execute("""SELECT phone,text,service,source,timestamp,otp_code,country_code,carrier,flag
                FROM otps WHERE service LIKE ? ORDER BY created_at DESC LIMIT ?""", (f"%{service}%", limit)).fetchall()
            return [{"phone": r[0], "text": r[1], "service": r[2], "source": r[3],
                     "timestamp": r[4], "otp_code": r[5], "country_code": r[6],
                     "carrier": r[7], "flag": r[8]} for r in rows]
