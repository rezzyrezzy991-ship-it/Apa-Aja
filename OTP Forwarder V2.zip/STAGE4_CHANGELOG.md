# Stage 4 Changelog — Fetchers / Utils / Database

- Replaced synchronous `requests.Session` fetchers with async `httpx.AsyncClient`.
- Added concurrent async fetching for NumberPanel, INT inbox, INT dashboard and Legacy sources.
- Added `tenacity` retry/backoff around transient HTTP failures.
- Added Pydantic `OTPEntry` model for normalized OTP records.
- Replaced unbounded manual service/country caches with `cachetools.TTLCache`.
- Moved OTP parsing/service detection and phone metadata into dedicated utility modules.
- Enabled SQLite WAL, `foreign_keys=ON`, busy timeout, and `synchronous=NORMAL`.
- Preserved the existing SQLite schema and database contents.
- Preserved the legacy resend flow, scanner interval, source normalization and de-duplication behavior.
- Added pytest coverage for OTP extraction, service detection, number masking and SQLite settings.
- Removed runtime dependency on `requests` from the application code.

## Validation

- Python compileall: PASS
- Pytest: 6 passed
- Existing `.db` and `.db.bak` retained.
- No original credential values copied into new source files or `.env.example`.
