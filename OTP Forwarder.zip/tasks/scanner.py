"""Scanner task entry point."""
from ..core import run_scanner
__all__ = ["run_scanner"]
