"""Convenience launcher for Pterodactyl and local shells."""
import asyncio

from otp_forwarder.main import main

if __name__ == "__main__":
    asyncio.run(main())
