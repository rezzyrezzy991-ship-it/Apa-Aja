"""Rich Message builders for the Telegram UI.

Telegram's current Bot API exposes ``sendRichMessage`` for rich content. There
is no ``editRichMessage`` method, so handlers replace an existing rich message
by deleting it and sending the new rich message while preserving the inline
keyboard navigation.
"""
from __future__ import annotations

from datetime import datetime
from typing import Iterable, Sequence

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputRichBlockDivider,
    InputRichBlockList,
    InputRichBlockListItem,
    InputRichBlockParagraph,
    InputRichBlockPreformatted,
    InputRichBlockSectionHeading,
    InputRichBlockTable,
    InputRichMessage,
    RichBlockTableCell,
    RichTextBold,
    RichTextCode,
    CopyTextButton,
)

from .. import core


def _text(value: object) -> str:
    return str(value if value is not None else "—")


def _cell(value: object, *, header: bool = False, align: str = "left") -> RichBlockTableCell:
    return RichBlockTableCell(
        align=align,
        valign="middle",
        text=RichTextBold(text=_text(value)) if header else _text(value),
        is_header=header,
    )


def table(headers: Sequence[object], rows: Iterable[Sequence[object]]) -> InputRichBlockTable:
    cells = [[_cell(v, header=True) for v in headers]]
    cells.extend([[_cell(v) for v in row] for row in rows])
    return InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True, is_compact=True)


def _heading(title: str, size: int = 1) -> InputRichBlockSectionHeading:
    return InputRichBlockSectionHeading(text=title, size=size)


def _paragraph(text: str) -> InputRichBlockParagraph:
    return InputRichBlockParagraph(text=text)


def _commands_list() -> InputRichBlockList:
    commands = [
        ("/stats", "System statistics"),
        ("/traffic", "Live traffic snapshot"),
        ("/search <service>", "Search the OTP database"),
        ("/groups", "List target groups"),
        ("/backup", "Create a backup archive"),
        ("/resend [count|all]", "Resend selected records"),
        ("/addgroup", "Register the current group"),
        ("/removegroup", "Remove the current group"),
        ("/status", "Engine diagnostics"),
        ("/clearcache", "Clear runtime caches"),
        ("/help", "Show command help"),
    ]
    return InputRichBlockList(
        items=[
            InputRichBlockListItem(
                blocks=[_paragraph([RichTextCode(text=cmd), " — ", desc])]
            )
            for cmd, desc in commands
        ]
    )


def main_message() -> InputRichMessage:
    stats = core.db.get_stats()
    return InputRichMessage(
        blocks=[
            _heading("⚡ OTP FORWARDER ENGINE"),
            _paragraph("Modern OTP forwarding control center with live statistics, traffic monitoring and database tools."),
            table(
                ["Metric", "Value"],
                [
                    ["Total OTP", f"{stats['total']:,}"],
                    ["Groups", str(len(core.db.get_groups()))],
                    ["Uptime", str(datetime.now() - core.START_TIME).split(".")[0]],
                ],
            ),
            InputRichBlockDivider(),
            _heading("Commands", 3),
            _commands_list(),
        ]
    )


def stats_message() -> InputRichMessage:
    stats = core.db.get_stats()
    top_service = next(iter(stats["by_service"]), "Unknown")
    top_country = next(iter(stats["by_country"]), "UN")
    return InputRichMessage(
        blocks=[
            _heading("📊 STATISTICS"),
            _paragraph("Current database volume and recent OTP activity."),
            table(
                ["Metric", "Value"],
                [
                    ["Total", f"{stats['total']:,}"],
                    ["Last Hour", f"{stats['last_hour']:,}"],
                    ["24 Hours", f"{stats['last_24h']:,}"],
                    ["Top Service", top_service],
                    ["Top Country", top_country],
                ],
            ),
        ]
    )


def _progress(count: int, total: int, width: int = 12) -> str:
    if total <= 0:
        return "░" * width
    filled = max(0, min(width, round((count / total) * width)))
    return "█" * filled + "░" * (width - filled)


def traffic_message() -> InputRichMessage | None:
    data = core.db.get_live_traffic_30m()
    if not data:
        return InputRichMessage(
            blocks=[_heading("⚡ LIVE TRAFFIC"), _paragraph("No active traffic recorded in the last 30 minutes.")]
        )
    total, countries, services = data
    country_rows = [
        [f"{row['flag']} {row['country']}", row['count'], f"{row['count'] / total * 100:.1f}%"]
        for row in countries
    ]
    service_rows = [[row["service"], row["count"]] for row in services]
    return InputRichMessage(
        blocks=[
            _heading("⚡ LIVE TRAFFIC"),
            _paragraph(f"Last 30 minutes · {total:,} OTP records"),
            table(["Country", "Count", "Share"], country_rows or [["—", 0, "0%"]]),
            InputRichBlockDivider(),
            table(["Service", "Count"], service_rows or [["—", 0]]),
            InputRichBlockDivider(),
            _paragraph(f"Traffic intensity  {_progress(total, max(total, 100))}  {min(100, total)}%"),
        ]
    )


def groups_message() -> InputRichMessage:
    groups = core.db.get_groups()
    rows = [[title or "Group", str(chat_id)] for chat_id, title in groups]
    return InputRichMessage(
        blocks=[
            _heading("👥 TARGET GROUPS"),
            _paragraph(f"Registered broadcast destinations: {len(groups)}"),
            table(["Group", "Chat ID"], rows or [["No groups", "—"]]),
        ]
    )


def settings_message(owner: bool) -> InputRichMessage:
    if not owner:
        return InputRichMessage(blocks=[_heading("🔒 SETTINGS"), _paragraph("Owner-only settings.")])
    return InputRichMessage(
        blocks=[
            _heading("⚙️ SETTINGS"),
            table(
                ["Setting", "Status"],
                [["Scanner", "ON"], ["Traffic poster", "ON"], ["Hourly backup", "ON"]],
            ),
        ]
    )


def search_message() -> InputRichMessage:
    return InputRichMessage(
        blocks=[
            _heading("🔍 SEARCH DATABASE"),
            _paragraph("Use /search <service> to search OTP records by service name."),
            InputRichBlockPreformatted(text="/search WhatsApp", language="text"),
        ]
    )


def backup_message() -> InputRichMessage:
    return InputRichMessage(
        blocks=[_heading("📦 BACKUP"), _paragraph("Create a database/source backup with /backup.")]
    )


def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Statistics", callback_data="menu:stats"), InlineKeyboardButton(text="⚡ Live Traffic", callback_data="menu:traffic")],
        [InlineKeyboardButton(text="🔍 Search DB", callback_data="menu:search"), InlineKeyboardButton(text="📦 Backup", callback_data="menu:backup")],
        [InlineKeyboardButton(text="👥 Groups", callback_data="menu:groups"), InlineKeyboardButton(text="⚙️ Settings", callback_data="menu:settings")],
    ])


def stats_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Refresh", callback_data="action:refresh_stats"), InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")],
    ])


def traffic_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Refresh", callback_data="action:refresh_traffic"), InlineKeyboardButton(text="📌 Pin Now", callback_data="action:pin_traffic")],
        [InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")],
    ])


def groups_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Add", callback_data="action:add_group"), InlineKeyboardButton(text="➖ Remove", callback_data="action:remove_group")],
        [InlineKeyboardButton(text="🔄 Refresh", callback_data="action:refresh_groups"), InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")],
    ])


def settings_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Refresh", callback_data="action:refresh_settings"), InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")],
    ])


def search_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")]])


def backup_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📦 Create Backup", callback_data="action:create_backup"), InlineKeyboardButton(text="⬅️ Back", callback_data="menu:main")]])


def otp_keyboard(otp: str) -> InlineKeyboardMarkup:
    # CopyTextButton is a Bot API 10.x native copy-to-clipboard button.
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📋 Copy {otp}", copy_text=CopyTextButton(text=str(otp)))],
        [InlineKeyboardButton(text="🎥 Methods", url="https://youtube.com/@xclusor"), InlineKeyboardButton(text="📢 Channel", url="https://whatsapp.com/channel/0029VbC0kzIEFeXq9XLgHZ3y")],
        [InlineKeyboardButton(text="ℹ️ Detail", callback_data="otp:detail"), InlineKeyboardButton(text="🧩 Methods", callback_data="otp:methods")],
    ])
