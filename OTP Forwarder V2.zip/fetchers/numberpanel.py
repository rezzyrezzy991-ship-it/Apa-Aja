"""NumberPanel API fetcher using the endpoints preserved from the legacy bot."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx

from .http import request_json


async def fetch_numberpanel(
    client: httpx.AsyncClient,
    *,
    base_url: str,
    api_key: str,
    timeout: float,
) -> list[dict[str, Any]]:
    """Fetch from /api/otp, /api/my_otps and /api/latest_otp."""
    root = base_url.rstrip("/")
    sources = [
        ("🌟 Panel", f"{root}/api/otp?count=500", None),
        ("🔥 Key", f"{root}/api/otp?count=500", api_key),
        ("📱 MyOTP", f"{root}/api/my_otps?limit=200", api_key),
        ("⚡ Latest", f"{root}/api/latest_otp", api_key),
    ]
    entries: list[dict[str, Any]] = []
    import logging

    logger = logging.getLogger(__name__)
    for source, url, auth in sources:
        try:
            headers = {"Authorization": f"Bearer {auth}"} if auth else None
            data = await request_json(client, "GET", url, timeout=timeout, headers=headers)
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, (list, tuple)) and len(item) >= 3:
                        phone, text = item[1], item[2]
                        if phone and text:
                            entries.append(
                                {
                                    "phone": str(phone),
                                    "text": str(text),
                                    "service": str(item[0]),
                                    "source": source,
                                    "timestamp": item[3] if len(item) > 3 else datetime.now().isoformat(),
                                }
                            )
            elif isinstance(data, dict) and data.get("success"):
                if isinstance(data.get("otps"), list):
                    for item in data["otps"]:
                        if not isinstance(item, dict):
                            continue
                        phone = item.get("number") or item.get("phone") or ""
                        text = item.get("message") or item.get("text") or item.get("content") or ""
                        if phone and text:
                            entries.append(
                                {
                                    "phone": str(phone),
                                    "text": str(text),
                                    "service": str(item.get("service") or item.get("app") or "Unknown"),
                                    "source": source,
                                    "timestamp": item.get("time") or item.get("created_at") or datetime.now().isoformat(),
                                }
                            )
                elif data.get("has_otp") and data.get("otp_code"):
                    entries.append(
                        {
                            "phone": "",
                            "text": f"OTP: {data['otp_code']}",
                            "service": "OTP",
                            "source": source,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )
        except Exception as exc:
            logger.error("NumberPanel source %s failed: %s", source, exc, exc_info=True)
    return entries
