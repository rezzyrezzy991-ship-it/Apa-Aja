"""SQLite persistence layer for OTP Forwarder."""
from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Iterator

logger = logging.getLogger(__name__)


class Database:
    """Synchronous SQLite repository used by short database operations."""

    def __init__(self, db_path: str, default_group_id: int = 0) -> None:
        self.db_path = db_path
        self.default_group_id = default_group_id
        self._init_db()

    @contextmanager
    def _get_conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=10000")
        try:
            yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._get_conn() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS otps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    phone TEXT,
                    text TEXT,
                    service TEXT,
                    source TEXT,
                    timestamp TEXT,
                    otp_code TEXT,
                    country TEXT,
                    country_code TEXT,
                    carrier TEXT,
                    flag TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS target_groups (
                    chat_id INTEGER PRIMARY KEY,
                    title TEXT,
                    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_otps_phone ON otps(phone)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_otps_service ON otps(service)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_otps_timestamp ON otps(timestamp)")
            if self.default_group_id:
                conn.execute(
                    "INSERT OR IGNORE INTO target_groups (chat_id, title) VALUES (?, ?)",
                    (self.default_group_id, "Primary Group"),
                )
            conn.commit()

    def add_group(self, chat_id: int, title: str) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO target_groups (chat_id, title) VALUES (?, ?)",
                    (chat_id, title),
                )
                conn.commit()
            return True
        except sqlite3.Error as exc:
            logger.error("Add group database error: %s", exc, exc_info=True)
            return False

    def remove_group(self, chat_id: int) -> bool:
        try:
            with self._get_conn() as conn:
                cursor = conn.execute("DELETE FROM target_groups WHERE chat_id = ?", (chat_id,))
                conn.commit()
            return cursor.rowcount > 0
        except sqlite3.Error as exc:
            logger.error("Remove group database error: %s", exc, exc_info=True)
            return False

    def get_groups(self) -> list[tuple[int, str]]:
        try:
            with self._get_conn() as conn:
                rows = conn.execute("SELECT chat_id, title FROM target_groups ORDER BY added_at").fetchall()
            return [(int(row["chat_id"]), str(row["title"] or "Group")) for row in rows]
        except sqlite3.Error as exc:
            logger.error("Get groups database error: %s", exc, exc_info=True)
            return []

    def save_otp(self, entry: dict[str, Any]) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute(
                    """
                    INSERT INTO otps (
                        phone, text, service, source, timestamp, otp_code,
                        country, country_code, carrier, flag
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        entry.get("phone", ""),
                        entry.get("text", ""),
                        entry.get("service", "Unknown"),
                        entry.get("source", ""),
                        entry.get("timestamp", datetime.now().isoformat()),
                        entry.get("otp_code", ""),
                        entry.get("country", ""),
                        entry.get("country_code", "UN"),
                        entry.get("carrier", "Unknown"),
                        entry.get("flag", "🌐"),
                    ),
                )
                conn.commit()
            return True
        except sqlite3.Error as exc:
            logger.error("Save OTP database error: %s", exc, exc_info=True)
            return False

    def get_all_otps(self) -> list[dict[str, Any]]:
        try:
            with self._get_conn() as conn:
                rows = conn.execute(
                    """
                    SELECT phone, text, service, source, timestamp, otp_code,
                           country, country_code, carrier, flag
                    FROM otps ORDER BY id DESC
                    """
                ).fetchall()
            return [
                {
                    "phone": row["phone"],
                    "text": row["text"],
                    "service": row["service"],
                    "source": f"💾 DB ({row['source']})",
                    "timestamp": row["timestamp"],
                    "otp_code": row["otp_code"],
                    "country": row["country"],
                    "country_code": row["country_code"],
                    "carrier": row["carrier"],
                    "flag": row["flag"],
                }
                for row in rows
            ]
        except sqlite3.Error as exc:
            logger.error("Get all OTPs database error: %s", exc, exc_info=True)
            return []

    def get_stats(self) -> dict[str, Any]:
        stats: dict[str, Any] = {
            "total": 0,
            "by_source": {},
            "by_service": {},
            "by_country": {},
            "last_hour": 0,
            "last_24h": 0,
        }
        try:
            with self._get_conn() as conn:
                stats["total"] = conn.execute("SELECT COUNT(*) FROM otps").fetchone()[0]
                stats["by_source"] = {
                    str(row["source"]): int(row["count"])
                    for row in conn.execute(
                        "SELECT source, COUNT(*) AS count FROM otps GROUP BY source ORDER BY count DESC"
                    )
                }
                stats["by_service"] = {
                    str(row["service"]): int(row["count"])
                    for row in conn.execute(
                        "SELECT service, COUNT(*) AS count FROM otps "
                        "WHERE service != 'Unknown' GROUP BY service ORDER BY count DESC LIMIT 20"
                    )
                }
                stats["by_country"] = {
                    str(row["country_code"]): int(row["count"])
                    for row in conn.execute(
                        "SELECT country_code, COUNT(*) AS count FROM otps "
                        "WHERE country_code != 'UN' GROUP BY country_code ORDER BY count DESC LIMIT 20"
                    )
                }
                stats["last_hour"] = conn.execute(
                    "SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-1 hour')"
                ).fetchone()[0]
                stats["last_24h"] = conn.execute(
                    "SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-24 hours')"
                ).fetchone()[0]
        except sqlite3.Error as exc:
            logger.error("Get stats database error: %s", exc, exc_info=True)
        return stats

    def get_live_traffic_30m(self) -> tuple[int, list[sqlite3.Row], list[sqlite3.Row]] | None:
        try:
            with self._get_conn() as conn:
                total = conn.execute(
                    "SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now','-30 minutes')"
                ).fetchone()[0]
                if not total:
                    return None
                countries = conn.execute(
                    """
                    SELECT country, country_code, flag, COUNT(*) AS count
                    FROM otps
                    WHERE created_at >= datetime('now','-30 minutes') AND country_code != 'UN'
                    GROUP BY country_code ORDER BY count DESC LIMIT 5
                    """
                ).fetchall()
                services = conn.execute(
                    """
                    SELECT service, COUNT(*) AS count
                    FROM otps
                    WHERE created_at >= datetime('now','-30 minutes') AND service != 'Unknown'
                    GROUP BY service ORDER BY count DESC LIMIT 3
                    """
                ).fetchall()
            return int(total), countries, services
        except sqlite3.Error as exc:
            logger.error("Live traffic database error: %s", exc, exc_info=True)
            return None

    def search_by_service(self, service: str, limit: int = 50) -> list[dict[str, Any]]:
        try:
            with self._get_conn() as conn:
                rows = conn.execute(
                    """
                    SELECT phone, text, service, source, timestamp, otp_code,
                           country_code, carrier, flag
                    FROM otps
                    WHERE service LIKE ? ORDER BY created_at DESC LIMIT ?
                    """,
                    (f"%{service}%", limit),
                ).fetchall()
            return [
                {
                    "phone": row["phone"],
                    "text": row["text"],
                    "service": row["service"],
                    "source": row["source"],
                    "timestamp": row["timestamp"],
                    "otp_code": row["otp_code"],
                    "country_code": row["country_code"],
                    "carrier": row["carrier"],
                    "flag": row["flag"],
                }
                for row in rows
            ]
        except sqlite3.Error as exc:
            logger.error("Search database error: %s", exc, exc_info=True)
            return []
