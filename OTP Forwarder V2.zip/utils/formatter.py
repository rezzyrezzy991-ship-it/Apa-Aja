"""Compatibility formatting helpers."""
from ..core import format_otp_message, format_otp_rich_message

__all__ = ["format_otp_message", "format_otp_rich_message"]
