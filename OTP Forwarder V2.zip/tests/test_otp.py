from otp_forwarder.utils.otp import extract_otp, detect_service, mask_number

def test_extract_six_digit():
    assert extract_otp("Your verification code is 123456") == "123456"

def test_extract_split_code():
    assert extract_otp("Code 123-456") == "123456"

def test_extract_none():
    assert extract_otp("hello world") is None

def test_detect_service():
    assert detect_service("Your WhatsApp verification code is 123456") == "WhatsApp"

def test_mask_number():
    assert mask_number("628123456789") == "628***789"
