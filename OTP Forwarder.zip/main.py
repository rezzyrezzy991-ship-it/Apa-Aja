"""Application entry point for OTP Forwarder (aiogram 3.x)."""
import asyncio
import logging
import signal

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from .config import settings
from . import core
from .bot.handlers import router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

async def main() -> None:
    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except (NotImplementedError, RuntimeError):
            pass

    tasks = []
    try:
        if settings.int_username and settings.int_password:
            await core.int_login()
        core.START_TIME = __import__("datetime").datetime.now()
        logger.info("OTP Forwarder aiogram engine starting")
        tasks = [
            asyncio.create_task(core.run_scanner(bot), name="scanner"),
            asyncio.create_task(core.run_traffic_poster(bot), name="traffic-poster"),
            asyncio.create_task(core.run_hourly_backup(bot), name="hourly-backup"),
        ]
        polling_task = asyncio.create_task(dp.start_polling(bot), name="telegram-polling")
        await stop_event.wait()
        logger.info("Shutdown signal received")
        polling_task.cancel()
        await asyncio.gather(polling_task, return_exceptions=True)
    finally:
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        await bot.session.close()
        logger.info("Engine stopped cleanly")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
