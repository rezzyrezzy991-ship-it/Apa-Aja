# Stage 3 — Rich Message UI

## Implemented
- Native `InputRichMessage` builders for Main, Statistics, Live Traffic, Groups, Settings, Search and Backup menus.
- `sendRichMessage` via aiogram `Message.answer_rich()` / `Bot.send_rich_message()`.
- Rich headings, paragraphs, dividers, lists, tables and preformatted OTP code blocks.
- Native `CopyTextButton` support on OTP inline keyboard.
- Existing callback namespaces retained: `menu:*` and `action:*`.
- Rich-message navigation uses delete + send because Bot API currently exposes `sendRichMessage` but not `editRichMessage`.
- OTP broadcasting switched from `sendMessage` HTML to native Rich Messages.
- Legacy commands remain available as fallback.

## Compatibility note
The project requirement is `aiogram>=3.29`. Rich blocks such as `InputRichBlockTable`, `InputRichBlockDetails`, list and preformatted blocks are documented in current aiogram 3.x. The current Bot API also documents Rich Messages and `CopyTextButton`.

## Not yet changed
- Fetcher modernization to async `httpx.AsyncClient`.
- TTLCache migration.
- Tenacity retry migration.
- Full Pydantic OTP model.
- pytest suite and final README polishing.
These are reserved for Stage 4/5.
