"""Callback-data helpers used by the Stage 2 UI."""
MENU_PREFIX = "menu:"
ACTION_PREFIX = "action:"
LEGACY_STATS = "stats"

def is_menu(data: str | None) -> bool:
    return bool(data and data.startswith(MENU_PREFIX))

def is_action(data: str | None) -> bool:
    return bool(data and data.startswith(ACTION_PREFIX))
