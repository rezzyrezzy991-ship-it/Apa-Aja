"""Pure OTP parsing and service detection utilities."""
from __future__ import annotations
import re
from typing import Optional
from cachetools import TTLCache

SERVICE_PATTERNS = {
    "Telegram": [r"telegram", r"tg", r"@telegram"],
    "WhatsApp": [r"whatsapp", r"wa", r"whats app"],
    "WeChat": [r"wechat"],
    "Line": [r"line\b", r"LINE"],
    "KakaoTalk": [r"kakao", r"kakaotalk"],
    "Viber": [r"viber"],
    "Signal": [r"signal"],
    "Discord": [r"discord", r"dc"],
    "Facebook": [r"facebook", r"fb", r"meta"],
    "Twitter": [r"twitter", r"x\b", r"@x"],
    "Instagram": [r"instagram", r"ig", r"@ig"],
    "TikTok": [r"tiktok", r"tt", r"@tt"],
    "Snapchat": [r"snapchat", r"sc", r"snap"],
    "Gmail": [r"gmail", r"google mail"],
    "Google": [r"google", r"g-", r"verification", r"verify"],
    "Shopee": [r"shopee"],
    "Lazada": [r"lazada"],
    "Tokopedia": [r"tokopedia"],
    "Gopay": [r"gopay", r"go-pay"],
    "OVO": [r"ovo", r"OVO"],
    "DANA": [r"dana", r"DANA"],
}

_service_cache = TTLCache(maxsize=50000, ttl=50000)

def mask_number(num: str) -> str:
    num = str(num).replace('+', '').replace('-', '').replace(' ', '')
    if len(num) <= 6:
        return num
    return num[:3] + "***" + num[-3:]

def extract_otp(text: str) -> Optional[str]:
    if not text:
        return None
    patterns = [
        r'\b(\d{6})\b',
        r'\b(\d{4})\b',
        r'\b(\d{3})[- ](\d{3})\b',
        r'\b(\d{3})[- ](\d{4})\b',
        r'(?:otp|code|pin|kode|passcode|verification code)[:\s]*(\d{4,6})',
        r'(\d{6}) is your (?:verification code|OTP|login code)',
        r'your (?:verification code|OTP|login code) is (\d{4,6})',
        r'(\d{4,6}) is your (?:One Time Password|OTP)',
        r'Use code (\d{4,6})',
        r'verification code:?\s*(\d{4,6})',
        r'code:?\s*(\d{4,6})',
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            groups = match.groups()
            if len(groups) == 2:
                return groups[0] + groups[1]
            return match.group(1)
    return None

def detect_service(text: str) -> str:
    text_lower = text.lower()
    if text_lower in _service_cache:
        return _service_cache[text_lower]
    for service, patterns in SERVICE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                _service_cache[text_lower] = service
                return service
    _service_cache[text_lower] = "Unknown"
    return "Unknown"

