"""Typed domain models for OTP records."""
from __future__ import annotations
from datetime import datetime
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

class OTPEntry(BaseModel):
    """Normalized OTP record shared by fetchers, storage and delivery."""
    model_config = ConfigDict(extra="allow")
    phone: str = ""
    text: str = ""
    service: str = "Unknown"
    source: str = ""
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    otp_code: str = ""
    country: str = ""
    country_code: str = "UN"
    carrier: str = "Unknown"
    flag: str = "🌐"

    def key(self) -> str:
        return f"{self.phone}_{self.text[:30]}"

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump()
