"""Async HTTP helpers with bounded retry/backoff."""
from __future__ import annotations
from typing import Any
import httpx
from tenacity import AsyncRetrying, retry_if_exception_type, stop_after_attempt, wait_exponential

DEFAULT_HEADERS = {"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"}

async def request_json(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    timeout: float,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | None = None,
    data: dict[str, Any] | None = None,
) -> Any:
    """Fetch JSON, retrying transient HTTP/network failures."""
    merged = {**DEFAULT_HEADERS, **(headers or {})}
    async for attempt in AsyncRetrying(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.25, min=0.25, max=2),
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError)),
        reraise=True,
    ):
        with attempt:
            response = await client.request(method, url, headers=merged, params=params, data=data, timeout=timeout)
            response.raise_for_status()
            return response.json()
    raise RuntimeError("unreachable")
