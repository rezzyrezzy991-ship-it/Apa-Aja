"""INT inbox/dashboard async fetchers."""
from __future__ import annotations
from datetime import datetime
from typing import Any
import httpx
from .http import request_json

async def _fetch(url: str, source: str, client: httpx.AsyncClient, timeout: float) -> list[dict[str, Any]]:
    if not url:
        return []
    try:
        data = await request_json(client, "GET", url, timeout=timeout)
        items = data if isinstance(data, list) else data.get("data", []) if isinstance(data, dict) else []
        result = []
        for item in items:
            if isinstance(item, dict):
                phone = item.get("number") or item.get("phone") or item.get("cli") or ""
                text = item.get("message") or item.get("text") or item.get("content") or ""
                if phone and text:
                    result.append({"phone": phone, "text": text, "service": item.get("app") or item.get("application") or "SMS", "source": source, "timestamp": item.get("time") or item.get("date") or datetime.now().isoformat()})
        return result
    except Exception:
        return []

async def fetch_int_inbox(client: httpx.AsyncClient, *, url: str, timeout: float) -> list[dict[str, Any]]:
    return await _fetch(url, "📨 Inbox", client, timeout)

async def fetch_int_dashboard(client: httpx.AsyncClient, *, url: str, timeout: float) -> list[dict[str, Any]]:
    return await _fetch(url, "📊 Dashboard", client, timeout)

async def int_login(client: httpx.AsyncClient, *, url: str, username: str, password: str, timeout: float) -> bool:
    if not url:
        return False
    try:
        response = await client.post(url, data={"username": username, "password": password}, timeout=timeout)
        return response.status_code == 200
    except Exception:
        return False
