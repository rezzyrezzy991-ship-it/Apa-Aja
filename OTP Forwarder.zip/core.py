# -*- coding: utf-8 -*-
"""Compatibility core for the Stage 2 aiogram migration.

Business logic is kept deliberately close to the original implementation;
Telegram transport and handlers are now provided by aiogram 3.x.
"""
import asyncio
import html
import logging
import os
import re
import sqlite3
import time
import random
import threading
import zipfile
from collections import defaultdict, deque
from contextlib import contextmanager
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, Dict, List, Optional, Tuple

import httpx

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, InputRichMessage, InputRichBlockSectionHeading, InputRichBlockParagraph, InputRichBlockPreformatted, InputRichBlockTable, RichBlockTableCell
from .bot.menus import otp_keyboard

from .config import settings
from .database import Database
from .utils.models import OTPEntry
from .fetchers.numberpanel import fetch_numberpanel as fetch_numberpanel_async
from .fetchers.ints import fetch_int_inbox as fetch_int_inbox_async, fetch_int_dashboard as fetch_int_dashboard_async, int_login as int_login_async
from .fetchers.legacy import fetch_legacy as fetch_legacy_async

logger = logging.getLogger(__name__)

BOT_TOKEN = settings.bot_token
DEFAULT_GROUP_ID = settings.default_group_id
OWNER_ID = settings.owner_id
YOUR_BOT_NAME = settings.bot_name
API_KEY = settings.api_key
BASE_URL = settings.base_url
INT_LOGIN_URL = settings.int_login_url
INT_INBOX_URL = settings.int_inbox_url
INT_DASHBOARD_URL = settings.int_dashboard_url
INT_USERNAME = settings.int_username
INT_PASSWORD = settings.int_password
INT_COOKIE = settings.int_cookie
LEGACY_URL = settings.legacy_url
LEGACY_TOKEN = settings.legacy_token
SCAN_INTERVAL = settings.scan_interval
REQUEST_TIMEOUT = settings.request_timeout
MAX_WORKERS = settings.max_workers
CACHE_MAX_SIZE = settings.cache_max_size
DB_PATH = settings.db_path

BROADCAST_SEMAPHORE = asyncio.Semaphore(15)


# FLAGS MAP
# ============================================================================
FLAG_MAP = {
    "AC": "🇦🇨", "AD": "🇦🇩", "AE": "🇦🇪", "AF": "🇦🇫", "AG": "🇦🇬",
    "AI": "🇦🇮", "AL": "🇦🇱", "AM": "🇦🇲", "AO": "🇦🇴", "AQ": "🇦🇶",
    "AR": "🇦🇷", "AS": "🇦🇸", "AT": "🇦🇹", "AU": "🇦🇺", "AW": "🇦🇼",
    "AX": "🇦🇽", "AZ": "🇦🇿", "BA": "🇧🇦", "BB": "🇧🇧", "BD": "🇧🇩",
    "BE": "🇧🇪", "BF": "🇧🇫", "BG": "🇧🇬", "BH": "🇧🇭", "BI": "🇧🇮",
    "BJ": "🇧🇯", "BL": "🇧🇱", "BM": "🇧🇲", "BN": "🇧🇳", "BO": "🇧🇴",
    "BQ": "🇧🇶", "BR": "🇧🇷", "BS": "🇧🇸", "BT": "🇧🇹", "BV": "🇧🇻",
    "BW": "🇧🇼", "BY": "🇧🇾", "BZ": "🇧🇿", "CA": "🇨🇦", "CC": "🇨🇨",
    "CD": "🇨🇩", "CF": "🇨🇫", "CG": "🇨🇬", "CH": "🇨🇭", "CI": "🇨🇮",
    "CK": "🇨🇰", "CL": "🇨🇱", "CM": "🇨🇲", "CN": "🇨🇳", "CO": "🇨🇴",
    "CP": "🇨🇵", "CR": "🇨🇷", "CU": "🇨🇺", "CV": "🇨🇻", "CW": "🇨🇼",
    "CX": "🇨🇽", "CY": "🇨🇾", "CZ": "🇨🇿", "DE": "🇩🇪", "DG": "🇩🇬",
    "DJ": "🇩🇯", "DK": "🇩🇰", "DM": "🇩🇲", "DO": "🇩🇴", "DZ": "🇩🇿",
    "EA": "🇪🇦", "EC": "🇪🇨", "EE": "🇪🇪", "EG": "🇪🇬", "EH": "🇪🇷",
    "ER": "🇪🇷", "ES": "🇪🇸", "ET": "🇪🇹", "EU": "🇪🇺", "FI": "🇫🇮",
    "FJ": "🇫🇯", "FK": "🇫🇰", "FM": "🇫🇲", "FO": "🇫🇴", "FR": "🇫🇷",
    "GA": "🇬🇦", "GB": "🇬🇧", "GD": "🇬🇩", "GE": "🇬🇪", "GF": "🇬🇫",
    "GG": "🇬🇬", "GH": "🇬🇭", "GI": "🇬🇮", "GL": "🇬🇱", "GM": "🇬🇲",
    "GN": "🇬🇳", "GP": "🇬🇵", "GQ": "🇬🇶", "GR": "🇬🇷", "GS": "🇬🇸",
    "GT": "🇬🇹", "GU": "🇬🇺", "GW": "🇬🇼", "GY": "🇬🇾", "HK": "🇭🇰",
    "HM": "🇭🇲", "HN": "🇭🇳", "HR": "🇭🇷", "HT": "🇭🇹", "HU": "🇭🇺",
    "IC": "🇮🇨", "ID": "🇮🇩", "IE": "🇮🇪", "IL": "🇮🇱", "IM": "🇮🇲",
    "IN": "🇮🇳", "IO": "🇮🇴", "IQ": "🇮🇶", "IR": "🇮🇷", "IS": "🇮🇸",
    "IT": "🇮🇹", "JE": "🇯🇪", "JM": "🇯🇲", "JO": "🇯🇴", "JP": "🇯🇵",
    "KE": "🇰🇪", "KG": "🇰🇬", "KH": "🇰🇭", "KI": "🇰🇮", "KM": "🇰🇲",
    "KN": "🇰🇳", "KP": "🇰🇵", "KR": "🇰🇷", "KW": "🇰🇼", "KY": "🇰🇾",
    "KZ": "🇰🇿", "LA": "🇱🇦", "LB": "🇱🇧", "LC": "🇱🇨", "LI": "🇱🇮",
    "LK": "🇱🇰", "LR": "🇱🇷", "LS": "🇱🇸", "LT": "🇱🇹", "LU": "🇱🇺",
    "LV": "🇱🇻", "LY": "🇱🇾", "MA": "🇲🇦", "MC": "🇲🇨", "MD": "🇲🇩",
    "ME": "🇲🇪", "MF": "🇲🇫", "MG": "🇲🇬", "MH": "🇲🇭", "MK": "🇲🇰",
    "ML": "🇲🇱", "MM": "🇲🇲", "MN": "🇲🇳", "MO": "🇲🇴", "MP": "🇲🇵",
    "MQ": "🇲🇶", "MR": "🇲🇷", "MS": "🇲🇸", "MT": "🇲🇹", "MU": "🇲🇺",
    "MV": "🇲🇻", "MW": "🇲🇼", "MX": "🇲🇽", "MY": "🇲🇾", "MZ": "🇲🇿",
    "NA": "🇳🇦", "NC": "🇳🇨", "NE": "🇳🇪", "NF": "🇳🇫", "NG": "🇳🇬",
    "NI": "🇳🇮", "NL": "🇳🇱", "NO": "🇳🇴", "NP": "🇳🇵", "NR": "🇳🇷",
    "NU": "🇳🇺", "NZ": "🇳🇿", "OM": "🇴🇲", "PA": "🇵🇦", "PE": "🇵🇪",
    "PF": "🇵🇫", "PG": "🇵🇬", "PH": "🇵🇭", "PK": "🇵🇰", "PL": "🇵🇱",
    "PM": "🇵🇲", "PN": "🇵🇳", "PR": "🇵🇷", "PS": "🇵🇸", "PT": "🇵🇹",
    "PW": "🇵🇼", "PY": "🇵🇾", "QA": "🇶🇦", "RE": "🇷🇪", "RO": "🇷🇴",
    "RS": "🇷🇸", "RU": "🇷🇺", "RW": "🇷🇼", "SA": "🇸🇦", "SB": "🇸🇧",
    "SC": "🇸🇨", "SD": "🇸🇩", "SE": "🇸🇪", "SG": "🇸🇬", "SH": "🇸🇭",
    "SI": "🇸🇮", "SJ": "🇸🇯", "SK": "🇸🇰", "SL": "🇸🇱", "SM": "🇸🇲",
    "SN": "🇸🇳", "SO": "🇸🇴", "SR": "🇸🇷", "SS": "🇸SS", "ST": "🇸🇹",
    "SV": "🇸🇻", "SX": "🇸🇽", "SY": "🇸🇾", "SZ": "🇸🇿", "TA": "🇹🇦",
    "TC": "🇹🇨", "TD": "🇹🇩", "TF": "🇹🇫", "TG": "🇹🇬", "TH": "🇹🇭",
    "TJ": "🇹🇯", "TK": "🇹🇰", "TL": "🇹🇱", "TM": "🇹🇲", "TN": "🇹🇳",
    "TO": "🇹🇴", "TR": "🇹🇷", "TT": "🇹🇹", "TV": "🇹🇻", "TW": "🇹🇼",
    "TZ": "🇹🇿", "UA": "🇺🇦", "UG": "🇺🇬", "UM": "🇺🇲", "UN": "🇺🇳",
    "US": "🇺🇸", "UY": "🇺🇾", "UZ": "🇺🇿", "VA": "🇻🇦", "VC": "🇻🇨",
    "VE": "🇻🇪", "VG": "🇻🇬", "VI": "🇻🇮", "VN": "🇻🇳", "VU": "🇻🇺",
    "WF": "🇼🇫", "WS": "🇼🇸", "XK": "🇽🇰", "YE": "🇾🇪", "YT": "🇾🇹",
    "ZA": "🇿🇦", "ZM": "🇿🇲", "ZW": "🇿🇼"
}

from .utils.otp import mask_number, extract_otp, detect_service
from .utils.country import get_country_info, FLAG_MAP

# ============================================================================
# DATABASE
# ============================================================================
class Database:
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self._init_db()
    
    @contextmanager
    def _get_conn(self):
        conn = sqlite3.connect(self.db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def _init_db(self):
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS otps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    phone TEXT,
                    text TEXT,
                    service TEXT,
                    source TEXT,
                    timestamp TEXT,
                    otp_code TEXT,
                    country TEXT,
                    country_code TEXT,
                    carrier TEXT,
                    flag TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS target_groups (
                    chat_id INTEGER PRIMARY KEY,
                    title TEXT,
                    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_phone ON otps(phone)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_service ON otps(service)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_otps_timestamp ON otps(timestamp)")
            
            cursor.execute("INSERT OR IGNORE INTO target_groups (chat_id, title) VALUES (?, ?)", 
                           (DEFAULT_GROUP_ID, "Primary Group"))
            conn.commit()

    def add_group(self, chat_id: int, title: str) -> bool:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT OR REPLACE INTO target_groups (chat_id, title) VALUES (?, ?)", (chat_id, title))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Add Group DB Error: {e}")
            return False

    def remove_group(self, chat_id: int) -> bool:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM target_groups WHERE chat_id = ?", (chat_id,))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Remove Group DB Error: {e}")
            return False

    def get_groups(self) -> List[Tuple[int, str]]:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT chat_id, title FROM target_groups")
                return [(row['chat_id'], row['title']) for row in cursor.fetchall()]
        except Exception:
            return [(DEFAULT_GROUP_ID, "Primary Group")]
    
    def save_otp(self, entry) -> bool:
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO otps (
                        phone, text, service, source, timestamp,
                        otp_code, country, country_code, carrier, flag
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.get('phone', ''),
                    entry.get('text', ''),
                    entry.get('service', 'Unknown'),
                    entry.get('source', ''),
                    entry.get('timestamp', datetime.now().isoformat()),
                    entry.get('otp_code', ''),
                    entry.get('country', ''),
                    entry.get('country_code', ''),
                    entry.get('carrier', ''),
                    entry.get('flag', '')
                ))
                conn.commit()
                return True
        except Exception:
            return False

    def get_all_otps(self) -> List[Dict[str, Any]]:
        results = []
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT phone, text, service, source, timestamp, otp_code, country, country_code, carrier, flag
                    FROM otps 
                    ORDER BY id DESC
                """)
                for row in cursor.fetchall():
                    results.append({
                        "phone": row['phone'],
                        "text": row['text'],
                        "service": row['service'],
                        "source": f"💾 DB ({row['source']})",
                        "timestamp": row['timestamp'],
                        "otp_code": row['otp_code'],
                        "country": row['country'],
                        "country_code": row['country_code'],
                        "carrier": row['carrier'],
                        "flag": row['flag']
                    })
        except Exception as e:
            logger.error(f"Fetch DB All OTPs Error: {e}")
        return results
    
    def get_stats(self):
        stats = {"total": 0, "by_source": {}, "by_service": {}, "by_country": {}, "last_hour": 0, "last_24h": 0}
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM otps")
                stats["total"] = cursor.fetchone()[0]
                
                cursor.execute("""
                    SELECT source, COUNT(*) as count 
                    FROM otps 
                    GROUP BY source 
                    ORDER BY count DESC
                """)
                for row in cursor.fetchall():
                    stats["by_source"][row['source']] = row['count']
                
                cursor.execute("""
                    SELECT service, COUNT(*) as count 
                    FROM otps 
                    WHERE service != 'Unknown'
                    GROUP BY service 
                    ORDER BY count DESC
                    LIMIT 20
                """)
                for row in cursor.fetchall():
                    stats["by_service"][row['service']] = row['count']
                
                cursor.execute("""
                    SELECT country_code, COUNT(*) as count 
                    FROM otps 
                    WHERE country_code != 'UN'
                    GROUP BY country_code 
                    ORDER BY count DESC
                    LIMIT 20
                """)
                for row in cursor.fetchall():
                    stats["by_country"][row['country_code']] = row['count']
                
                cursor.execute("""
                    SELECT COUNT(*) FROM otps 
                    WHERE created_at >= datetime('now', '-1 hour')
                """)
                stats["last_hour"] = cursor.fetchone()[0]
                
                cursor.execute("""
                    SELECT COUNT(*) FROM otps 
                    WHERE created_at >= datetime('now', '-24 hours')
                """)
                stats["last_24h"] = cursor.fetchone()[0]
        except Exception:
            pass
        return stats

    def get_live_traffic_30m(self):
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM otps WHERE created_at >= datetime('now', '-30 minutes')")
                total = cursor.fetchone()[0]
                
                if total == 0: 
                    return None
                    
                cursor.execute("""
                    SELECT country, country_code, flag, COUNT(*) as count 
                    FROM otps 
                    WHERE created_at >= datetime('now', '-30 minutes') AND country_code != 'UN'
                    GROUP BY country_code 
                    ORDER BY count DESC LIMIT 5
                """)
                countries = cursor.fetchall()

                cursor.execute("""
                    SELECT service, COUNT(*) as count 
                    FROM otps 
                    WHERE created_at >= datetime('now', '-30 minutes') AND service != 'Unknown'
                    GROUP BY service 
                    ORDER BY count DESC LIMIT 3
                """)
                services = cursor.fetchall()
                
                return total, countries, services
        except Exception as e:
            logger.error(f"Traffic DB Error: {e}")
            return None
    
    def search_by_service(self, service: str, limit: int = 50):
        results = []
        try:
            with self._get_conn() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT phone, text, service, source, timestamp, otp_code, country_code, carrier, flag
                    FROM otps 
                    WHERE service LIKE ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                """, (f"%{service}%", limit))
                for row in cursor.fetchall():
                    results.append({
                        "phone": row[0],
                        "text": row[1],
                        "service": row[2],
                        "source": row[3],
                        "timestamp": row[4],
                        "otp_code": row[5],
                        "country_code": row[6],
                        "carrier": row[7],
                        "flag": row[8]
                    })
                return results
        except Exception:
            return []


# ============================================================================
# API FETCHERS
# ============================================================================
# ============================================================================
# ASYNC API FETCHERS
# ============================================================================
async def fetch_numberpanel(client: httpx.AsyncClient | None = None):
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        return await fetch_numberpanel_async(client, base_url=BASE_URL, api_key=API_KEY, timeout=REQUEST_TIMEOUT)
    finally:
        if owns:
            await client.aclose()

async def fetch_int_inbox(client: httpx.AsyncClient | None = None):
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        return await fetch_int_inbox_async(client, url=INT_INBOX_URL, timeout=REQUEST_TIMEOUT)
    finally:
        if owns:
            await client.aclose()

async def fetch_int_dashboard(client: httpx.AsyncClient | None = None):
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        return await fetch_int_dashboard_async(client, url=INT_DASHBOARD_URL, timeout=REQUEST_TIMEOUT)
    finally:
        if owns:
            await client.aclose()

async def fetch_legacy(client: httpx.AsyncClient | None = None):
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        return await fetch_legacy_async(client, url=LEGACY_URL, token=LEGACY_TOKEN, timeout=REQUEST_TIMEOUT)
    finally:
        if owns:
            await client.aclose()

async def int_login(client: httpx.AsyncClient | None = None) -> bool:
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        return await int_login_async(client, url=INT_LOGIN_URL, username=INT_USERNAME, password=INT_PASSWORD, timeout=REQUEST_TIMEOUT)
    finally:
        if owns:
            await client.aclose()

async def fetch_all(client: httpx.AsyncClient | None = None) -> list[dict[str, Any]]:
    """Fetch all configured sources concurrently and de-duplicate records."""
    owns = client is None
    if owns:
        client = httpx.AsyncClient(headers={"User-Agent": "Mozilla/5.0 OTP-Forwarder/4"})
    try:
        results = await asyncio.gather(
            fetch_numberpanel(client), fetch_int_inbox(client),
            fetch_int_dashboard(client), fetch_legacy(client),
            return_exceptions=True,
        )
        all_entries: list[dict[str, Any]] = []
        for result in results:
            if isinstance(result, Exception):
                logger.warning("Fetcher failed: %s", result)
                continue
            all_entries.extend(result)
        unique: dict[str, dict[str, Any]] = {}
        for entry in all_entries:
            unique.setdefault(f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}", entry)
        return sorted(unique.values(), key=lambda x: x.get("timestamp", ""), reverse=True)
    finally:
        if owns:
            await client.aclose()

async def fetch_all_resend_sources() -> list[dict[str, Any]]:
    """Fetch live sources and persisted OTPs for the legacy resend command."""
    api_entries = await fetch_all()
    db_entries = db.get_all_otps()
    unique: dict[str, dict[str, Any]] = {}
    for entry in api_entries + db_entries:
        unique.setdefault(f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}", entry)
    return sorted(unique.values(), key=lambda x: x.get("timestamp", ""), reverse=True)

# ============================================================================
# LIVE TRAFFIC FORMATTER - REDESIGNED MODERN UI
# ============================================================================
def format_traffic_message(total, top_countries, top_services):
    bot_name_esc = html.escape(YOUR_BOT_NAME)
    now_str = datetime.now().strftime("%H:%M UTC")
    
    msg = (
        f"<b>🚀 {bot_name_esc.upper()}</b>\n"
        f"⚡ <b>LIVE TRAFFIC REPORT (30 MIN)</b>\n"
        f"<code>─────────────────────────</code>\n"
        f"📈 <b>Total OTP Volume:</b> <code>{total:,}</code>\n"
        f"🕒 <b>Last Updated:</b> <code>{now_str}</code>\n"
        f"<code>─────────────────────────</code>\n\n"
        f"<b>🌍 TOP ACTIVE COUNTRIES</b>\n"
    )
    
    medals = ["🥇", "🥈", "🥉", "🏅", "🏅"]
    for i, row in enumerate(top_countries):
        country = html.escape(row['country'])
        flag = row['flag']
        count = row['count']
        pct = (count / total) * 100
        
        filled = max(1, min(10, int((pct / 100) * 10)))
        bar = "█" * filled + "▒" * (10 - filled)
        medal = medals[i] if i < len(medals) else "🏅"
        
        msg += f"{medal} {flag} <b>{country}</b> — <code>{count:,}</code> ({pct:.1f}%)\n"
        msg += f"└ <code>[{bar}]</code>\n"
        
    if top_services:
        msg += f"\n<b>🔥 TOP DEMAND SERVICES</b>\n"
        for i, row in enumerate(top_services):
            srv = html.escape(row['service'])
            c_cnt = row['count']
            msg += f"• <b>{srv}:</b> <code>{c_cnt:,} codes</code>\n"

    msg += (
        f"\n<code>─────────────────────────</code>\n"
        f"<i>🔄 Automatically updated & pinned every 30 mins</i>"
    )
        
    return msg.strip()

# ============================================================================
# MESSAGE FORMATTER - SLEEK & MODERN DESIGN
# ============================================================================
def format_otp_message(entry):
    """Return the legacy OTP HTML body and an aiogram inline keyboard.

    Native CopyTextButton is deliberately added in Stage 3 with Rich Messages;
    Stage 2 keeps the safe callback fallback.
    """
    service = entry.get("service", "Unknown")
    text = entry.get("text", "")
    phone = entry.get("phone", "")
    source = entry.get("source", "")
    if service in ("Unknown", "SMS"):
        detected = detect_service(text)
        if detected != "Unknown":
            service = detected
    country_name, flag, iso, carrier_name = get_country_info(phone)
    masked = mask_number(phone)
    otp = entry.get("otp_code") or extract_otp(text) or "N/A"
    msg = (
        "<b>⚡ NEW OTP RECEIVED</b>\n"
        "─────────────────────────\n"
        f"🌐 <b>Service:</b> {html.escape(service)}\n"
        f"{flag} <b>Country:</b> {html.escape(country_name)} (<code>{html.escape(iso)}</code>)\n"
        f"📱 <b>Number:</b> <code>{html.escape(masked)}</code>\n"
        f"📡 <b>Carrier:</b> <code>{html.escape(carrier_name)}</code>\n"
        f"📥 <b>Source:</b> {html.escape(source)}\n"
        "─────────────────────────\n"
        "🔑 <b>Verification Code:</b>\n"
        f"<code>{html.escape(str(otp))}</code>\n"
        "─────────────────────────"
    )
    markup = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🔑 {otp}", callback_data="noop")],
        [InlineKeyboardButton(text="🎥 Methods", url="https://youtube.com/@xclusor"), InlineKeyboardButton(text="📢 Channel", url="https://whatsapp.com/channel/0029VbC0kzIEFeXq9XLgHZ3y")],
        [InlineKeyboardButton(text="🤖 OTP Panel Bot", url="https://t.me/XclusoRPanelBot")],
    ])
    return msg, markup


db = Database(DB_PATH)
if DEFAULT_GROUP_ID:
    db.add_group(DEFAULT_GROUP_ID, "Primary Group")
bot = None
SEEN_OTPS: set[str] = set()
START_TIME = datetime.now()

def format_otp_rich_message(entry: dict) -> tuple[InputRichMessage, InlineKeyboardMarkup]:
    """Build the Bot API Rich Message representation of an OTP entry."""
    service = entry.get("service", "Unknown")
    text = entry.get("text", "")
    phone = entry.get("phone", "")
    source = entry.get("source", "")
    if service in ("Unknown", "SMS"):
        detected = detect_service(text)
        if detected != "Unknown":
            service = detected
    country_name, flag, iso, carrier_name = get_country_info(phone)
    masked = mask_number(phone)
    otp = str(entry.get("otp_code") or extract_otp(text) or "N/A")
    cells = [
        [RichBlockTableCell(align="left", valign="middle", text="Service", is_header=True), RichBlockTableCell(align="left", valign="middle", text=str(service))],
        [RichBlockTableCell(align="left", valign="middle", text="Country", is_header=True), RichBlockTableCell(align="left", valign="middle", text=f"{flag} {country_name} ({iso})")],
        [RichBlockTableCell(align="left", valign="middle", text="Number", is_header=True), RichBlockTableCell(align="left", valign="middle", text=masked)],
        [RichBlockTableCell(align="left", valign="middle", text="Carrier", is_header=True), RichBlockTableCell(align="left", valign="middle", text=str(carrier_name))],
        [RichBlockTableCell(align="left", valign="middle", text="Source", is_header=True), RichBlockTableCell(align="left", valign="middle", text=str(source))],
    ]
    rich = InputRichMessage(blocks=[
        InputRichBlockSectionHeading(text="⚡ NEW OTP RECEIVED", size=1),
        InputRichBlockParagraph(text="A new verification message was detected."),
        InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True, is_compact=True),
        InputRichBlockParagraph(text="🔑 Verification Code"),
        InputRichBlockPreformatted(text=otp),
    ])
    return rich, otp_keyboard(otp)


async def broadcast_to_groups(bot_instance, rich_message: InputRichMessage, markup=None, auto_pin: bool = False) -> None:
    """Broadcast a native Rich Message to all registered groups."""
    async with BROADCAST_SEMAPHORE:
        for chat_id, title in db.get_groups():
            try:
                sent_msg = await bot_instance.send_rich_message(
                    chat_id=chat_id,
                    rich_message=rich_message,
                    reply_markup=markup,
                    disable_notification=False,
                )
                if auto_pin and sent_msg:
                    try:
                        await bot_instance.pin_chat_message(chat_id=chat_id, message_id=sent_msg.message_id, disable_notification=True)
                    except Exception as exc:
                        logger.warning("Could not pin message in group %s: %s", chat_id, exc)
            except Exception as exc:
                logger.error("Rich broadcast error for %s: %s", chat_id, exc)

async def send_to_group(bot_instance, entry: dict) -> bool:
    rich, markup = format_otp_rich_message(entry)
    await broadcast_to_groups(bot_instance, rich, markup=markup, auto_pin=False)
    return True

async def create_and_send_backup(bot_instance, chat_id: int) -> bool:
    """Create and send the same script/database backup as the legacy bot."""
    zip_filename = f"otp_bot_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    try:
        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            legacy = "otp_forwarder_copybutton.py.bak"
            if os.path.exists(legacy):
                zipf.write(legacy, arcname="otp_forwarder_copybutton.py")
            if os.path.exists(DB_PATH):
                zipf.write(DB_PATH, arcname=os.path.basename(DB_PATH))
        from aiogram.types import FSInputFile
        await bot_instance.send_document(
            chat_id=chat_id,
            document=FSInputFile(zip_filename),
            caption=(
                "<b>📦 SYSTEM BACKUP ARCHIVE</b>\n"
                "─────────────────────────\n"
                "📁 Contains:\n"
                "• Python source backup\n"
                f"• SQLite Database ({html.escape(os.path.basename(DB_PATH))})\n\n"
                f"🕒 <b>Timestamp:</b> <code>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</code>"
            ),
            parse_mode="HTML",
        )
        return True
    except Exception as exc:
        logger.error("Backup generation error: %s", exc)
        return False
    finally:
        if os.path.exists(zip_filename):
            os.remove(zip_filename)

async def run_scanner(bot_instance) -> None:
    """Run the original polling/scanning behavior with aiogram transport."""
    global SEEN_OTPS
    try:
        initial = await fetch_all()
        for entry in initial[:500]:
            key = f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}"
            SEEN_OTPS.add(key)
        logger.info("Loaded %s initial OTPs to cache", len(SEEN_OTPS))
    except Exception as exc:
        logger.error("Initial load error: %s", exc)

    while True:
        try:
            entries = await fetch_all()
            new_count = 0
            for entry in entries:
                key = f"{entry.get('phone', '')}_{entry.get('text', '')[:30]}"
                if key in SEEN_OTPS:
                    continue
                otp = extract_otp(entry.get('text', ''))
                if not otp:
                    continue
                entry['otp_code'] = otp
                country_name, flag, iso, carrier_name = get_country_info(entry.get('phone', ''))
                entry.update(country=country_name, country_code=iso, carrier=carrier_name, flag=flag)
                if entry.get('service') in ('Unknown', 'SMS'):
                    detected = detect_service(entry.get('text', ''))
                    if detected != 'Unknown':
                        entry['service'] = detected
                entry = OTPEntry.model_validate(entry).as_dict()
                db.save_otp(entry)
                if await send_to_group(bot_instance, entry):
                    SEEN_OTPS.add(key)
                    new_count += 1
                    logger.info("Sent OTP %s | %s | %s", otp, mask_number(entry.get('phone', '')), entry.get('service', 'Unknown'))
            if new_count:
                logger.info("Dispatched %s new OTP notifications", new_count)
            if len(SEEN_OTPS) > CACHE_MAX_SIZE:
                SEEN_OTPS = set(list(SEEN_OTPS)[-CACHE_MAX_SIZE // 2:])
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Scanner cycle error: %s", exc)
        await asyncio.sleep(SCAN_INTERVAL)

async def run_traffic_poster(bot_instance) -> None:
    while True:
        await asyncio.sleep(1800)
        try:
            data = db.get_live_traffic_30m()
            if data:
                await broadcast_to_groups(bot_instance, format_traffic_message(data[0], data[1], data[2]), auto_pin=True)
                logger.info("Sent 30-min live traffic report")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Auto-traffic poster error: %s", exc)

async def run_hourly_backup(bot_instance) -> None:
    while True:
        await asyncio.sleep(3600)
        try:
            logger.info("Triggering hourly automated system backup")
            await create_and_send_backup(bot_instance, OWNER_ID)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Hourly automated backup error: %s", exc)
