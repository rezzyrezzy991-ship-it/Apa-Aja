# Diff Summary

## Architecture

- `main.py`: aiogram dispatcher/polling lifecycle and graceful shutdown.
- `config.py`: `.env`-backed settings.
- `database.py`: SQLite persistence and statistics/search helpers.
- `core.py`: scanner, fetch orchestration, OTP formatting, broadcasting, backup, and background tasks.
- `fetchers/`: NumberPanel, INT, Legacy adapters plus retry support.
- `bot/`: Rich Message UI, keyboards, callbacks, and handlers.
- `tasks/`: background task exports.
- `utils/`: OTP parsing, country lookup, formatting, and models.

## Notable fixes

1. Fixed direct-execution relative-import failure in `otp_forwarder/main.py`.
2. Added a root `main.py` launcher so `python main.py` can be used from the project root.
3. Removed duplicate database implementation from `core.py`.
4. Replaced unlogged fetch failures with logged retry-aware fetchers.
5. Replaced unbounded seen-cache behavior with `TTLCache`.
6. Made broadcast/send results reflect actual successful deliveries.
7. Implemented OTP detail/methods/noop callbacks.
8. Implemented add/remove group callback behavior.
9. Added owner authorization to backup command and backup callback.
10. Made backup path resolution independent of the current working directory for package assets/database.
11. Made `.env` discovery relative to the package directory.
12. Added verification and known-issue documentation for the handoff boundary.
