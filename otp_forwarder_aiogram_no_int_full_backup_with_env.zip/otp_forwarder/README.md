# OTP Forwarder — aiogram 3.31+ / Bot API Rich Messages

Candidate handoff package for the original OTP Forwarder migration. The implementation is organized around aiogram 3.x, native Rich Messages, async fetchers, SQLite persistence, and background scanner/traffic/backup tasks.

## Handoff status

This ZIP is **not claimed as 100% clean**. Static checks completed in the build environment are documented in `AUDIT_FINAL.md`. Local lint/type/test/dependency/Telegram/live-endpoint checks that could not be executed are documented in `VERIFICATION_PENDING.md`.

## Install

```bash
cd otp_forwarder
python -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

Windows PowerShell activation:

```powershell
.\venv\Scripts\Activate.ps1
```

Edit `.env` and supply your own values. Never commit `.env`.

## Run

From the ZIP root:

```bash
python main.py
```

The package entrypoint also supports:

```bash
python -m otp_forwarder.main
```

## Commands

`/start` · `/help` · `/stats` · `/traffic` · `/search <service>` · `/status` · `/backup` · `/addgroup` · `/removegroup` · `/groups` · `/clearcache` · `/resend [count|all]`

## Rich UI

Main menu: Statistics, Live Traffic, Search DB, Backup, Groups and owner-only Settings.

Navigation uses `menu:*` and `action:*` callback namespaces. OTP messages expose Detail/Methods actions plus a native copy-OTP button and configured channel/link buttons.

## Verification

Run the full local verification sequence from `VERIFICATION_PENDING.md` before production use:

```bash
ruff check otp_forwarder/
mypy otp_forwarder/ --ignore-missing-imports
pytest -v
python main.py
```

Live endpoint and Telegram checks are deployment-specific and were not fabricated in this handoff.

## Backup files

- `otp_forwarder_copybutton.py.bak` — preserved original application source.
- `otp_forwarder.db.bak` — preserved original SQLite database.

Review preserved backups before sharing them because historical application data or credentials may be present. Keep real credentials only in a private `.env`.

## Security note

The distributed `.env.example` contains placeholders only. Put real credentials in
`otp_forwarder/.env` on the local machine and never commit or upload that file.
