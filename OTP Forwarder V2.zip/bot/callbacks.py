"""Callback-data constants and validation helpers."""
from __future__ import annotations

MENU_PREFIX = "menu:"
ACTION_PREFIX = "action:"
OTP_PREFIX = "otp:"
NOOP_CALLBACK = "noop"


def is_menu(data: str | None) -> bool:
    return bool(data and data.startswith(MENU_PREFIX))


def is_action(data: str | None) -> bool:
    return bool(data and data.startswith(ACTION_PREFIX))


def is_otp(data: str | None) -> bool:
    return bool(data and data.startswith(OTP_PREFIX))
