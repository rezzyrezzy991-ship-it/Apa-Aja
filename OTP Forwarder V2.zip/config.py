"""Environment-backed configuration for OTP Forwarder."""
from dataclasses import dataclass
import os
from pathlib import Path

from dotenv import load_dotenv

_BASE_DIR = Path(__file__).resolve().parent
load_dotenv(_BASE_DIR / ".env")

def _required(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value

def _int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))

def _float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))

@dataclass(frozen=True)
class Settings:
    bot_token: str
    owner_id: int
    default_group_id: int
    bot_name: str
    api_key: str
    base_url: str
    int_login_url: str
    int_inbox_url: str
    int_dashboard_url: str
    int_username: str
    int_password: str
    int_cookie: str
    legacy_url: str
    legacy_token: str
    scan_interval: float
    request_timeout: int
    max_workers: int
    cache_max_size: int
    db_path: str

def load_settings() -> Settings:
    return Settings(
        bot_token=_required("BOT_TOKEN"),
        owner_id=_int("OWNER_ID", 0),
        default_group_id=_int("DEFAULT_GROUP_ID", 0),
        bot_name=os.getenv("YOUR_BOT_NAME", "OTP Live Traffic"),
        api_key=_required("API_KEY"),
        base_url=os.getenv("BASE_URL", "https://numberpanel.tech"),
        int_login_url=os.getenv("INT_LOGIN_URL", ""),
        int_inbox_url=os.getenv("INT_INBOX_URL", ""),
        int_dashboard_url=os.getenv("INT_DASHBOARD_URL", ""),
        int_username=os.getenv("INT_USERNAME", ""),
        int_password=os.getenv("INT_PASSWORD", ""),
        int_cookie=os.getenv("INT_COOKIE", ""),
        legacy_url=os.getenv("LEGACY_URL", ""),
        legacy_token=os.getenv("LEGACY_TOKEN", ""),
        scan_interval=_float("SCAN_INTERVAL", 0.5),
        request_timeout=_int("REQUEST_TIMEOUT", 10),
        max_workers=_int("MAX_WORKERS", 8),
        cache_max_size=_int("CACHE_MAX_SIZE", 50000),
        db_path=os.getenv("DB_PATH", "otp_forwarder.db"),
    )

settings = load_settings()
