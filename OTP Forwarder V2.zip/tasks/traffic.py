"""Traffic task export."""
from ..core import run_traffic_poster

__all__ = ["run_traffic_poster"]
