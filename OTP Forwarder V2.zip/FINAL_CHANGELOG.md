# Handoff Changelog

## Migration / hardening changes

- Migrated bot entrypoint and handlers to aiogram 3.x architecture.
- Added native Rich Message builders and Rich Message editing/sending paths.
- Added structured main menu, statistics, traffic, groups, search, backup, and settings views.
- Added callback handling for menu, action, OTP, and noop namespaces.
- Preserved legacy slash-command surface while routing output through the modern UI where applicable.
- Added SQLite WAL/foreign-key/busy-timeout configuration and row access support.
- Added TTL-based `SEEN_OTPS` cache.
- Added tenacity-based fetch retries and fetcher error logging.
- Added real success/failure propagation from `send_to_group()`.
- Added owner checks for backup actions.
- Added direct `python main.py` launcher compatibility.
- Added graceful task/polling shutdown.
- Resolved `.env` loading relative to the package directory.
- Resolved backup source/database paths relative to the package when configured relatively.
- Removed dead duplicate database logic and forbidden placeholder constructs from the patched source.

## Verification boundary

The package is handed over with pending verification explicitly documented. It is not represented as 100% clean until local ruff, mypy, pytest, dependency installation, Telegram startup, and live endpoint tests are completed.
