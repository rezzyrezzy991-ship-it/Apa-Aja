"""INT inbox/dashboard asynchronous fetchers."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx

from .http import request_json


async def _fetch(
    url: str,
    source: str,
    client: httpx.AsyncClient,
    timeout: float,
) -> list[dict[str, Any]]:
    if not url:
        return []
    try:
        data = await request_json(client, "GET", url, timeout=timeout)
        items = data if isinstance(data, list) else data.get("data", []) if isinstance(data, dict) else []
        result: list[dict[str, Any]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            phone = item.get("number") or item.get("phone") or item.get("cli") or ""
            text = item.get("message") or item.get("text") or item.get("content") or ""
            if phone and text:
                result.append(
                    {
                        "phone": str(phone),
                        "text": str(text),
                        "service": item.get("app") or item.get("application") or "SMS",
                        "source": source,
                        "timestamp": item.get("time") or item.get("date") or datetime.now().isoformat(),
                    }
                )
        return result
    except Exception as exc:
        import logging

        logging.getLogger(__name__).error("%s fetch failed: %s", source, exc, exc_info=True)
        return []


async def fetch_int_inbox(client: httpx.AsyncClient, *, url: str, timeout: float) -> list[dict[str, Any]]:
    return await _fetch(url, "📨 Inbox", client, timeout)


async def fetch_int_dashboard(client: httpx.AsyncClient, *, url: str, timeout: float) -> list[dict[str, Any]]:
    return await _fetch(url, "📊 Dashboard", client, timeout)


async def int_login(
    client: httpx.AsyncClient,
    *,
    url: str,
    username: str,
    password: str,
    timeout: float,
) -> bool:
    """Authenticate using the legacy login endpoint with transient retry."""
    from tenacity import AsyncRetrying, retry_if_exception, stop_after_attempt, wait_exponential

    def retryable(exc: BaseException) -> bool:
        if isinstance(exc, (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError)):
            return True
        if isinstance(exc, httpx.HTTPStatusError):
            return exc.response.status_code >= 500
        return False

    try:
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(3),
            wait=wait_exponential(multiplier=0.25, min=0.25, max=2),
            retry=retry_if_exception(retryable),
            reraise=True,
        ):
            with attempt:
                response = await client.post(
                    url,
                    data={"username": username, "password": password},
                    timeout=timeout,
                )
                response.raise_for_status()
                return response.status_code == 200
    except Exception as exc:
        import logging

        logging.getLogger(__name__).error("INT login failed: %s", exc, exc_info=True)
        return False
    return False
