# Verification Pending

This package is a **candidate handoff**, not a claim of 100% clean status. The checks below are split between what was verified in the build environment and what could not be completed because the environment had no usable PyPI/DNS access and did not contain the requested lint/type-check tools.

## 1. Local commands to run

Linux/macOS:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
ruff check otp_forwarder/
mypy otp_forwarder/ --ignore-missing-imports
pytest -v
python main.py
```

Windows PowerShell:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
ruff check otp_forwarder/
mypy otp_forwarder/ --ignore-missing-imports
pytest -v
python main.py
```

For the cleanest verification, use Python 3.12 as requested. Python 3.13 is also the version used by the available build environment for syntax/AST checks.

## 2. Endpoint checks

The endpoint values below were preserved from the legacy source used for this migration. Their live availability was **not** verified from the build environment.

### NumberPanel
- Base URL: `https://numberpanel.tech`
- OTP endpoint: `https://numberpanel.tech/api/otp?count=500`
- My OTP endpoint: `https://numberpanel.tech/api/my_otps?limit=200`
- Latest OTP endpoint: `https://numberpanel.tech/api/latest_otp`

### INT

### Legacy
- Stats: `http://147.135.212.197/crapi/st/viewstats`

Manual check example (do not paste credentials into shell history if avoidable):

```bash
curl -I https://numberpanel.tech
curl -I http://147.135.212.197/crapi/st/viewstats
```

A non-200 HTTP status does not automatically mean the source is unusable; inspect the response and authentication requirements.

## 3. `.env` credentials/configuration to fill

Copy `.env.example` to `.env` and replace the placeholders:

- `BOT_TOKEN`
- `OWNER_ID`
- `DEFAULT_GROUP_ID`
- `API_KEY`
- `LEGACY_TOKEN`

The endpoint variables are already populated from the legacy source, but you should confirm they are still correct before production use.

**Do not commit `.env` or share it in a ZIP.**

## 4. Telegram bot command tests

Run the bot and test these commands in a private test chat first:

- `/start` — opens the main Rich Message menu.
- `/stats` — shows database statistics.
- `/traffic` — shows the 30-minute traffic snapshot.
- `/search WhatsApp` — searches stored OTP records by service.
- `/groups` — lists registered groups.
- `/backup` — creates and sends a backup archive. Owner permission should be checked according to the handler/configuration.
- `/resend 5` — attempts to resend the latest five available records.
- `/resend all` — attempts to resend all available records.
- `/addgroup` — run inside a group/supergroup to register it.
- `/removegroup` — run inside a registered group/supergroup to remove it.
- `/status` — engine diagnostics.
- `/clearcache` — clears runtime caches.
- `/help` — opens the command/help UI.

## 5. Menu/button tests

From `/start`:

1. Statistics → Refresh → Back.
2. Live Traffic → Refresh → Pin Now → Back.
3. Search DB → Back.
4. Backup → Create Backup (owner) → Back.
5. Groups → Refresh → Add/Remove Group when the menu is opened in the target group → Back.
6. Settings → Refresh → Back. Non-owner accounts should receive an owner-only response.

For an OTP notification, test:
- Copy OTP button.
- Detail button (`otp:detail`).
- Methods button (`otp:methods`).
- Channel button/link if configured by the keyboard.

## 6. Background task checks

Keep the bot running long enough to observe logs for:
- scanner startup and polling;
- INT login attempt when configured;
- fetcher retry/error logging;
- new OTP dispatch;
- traffic poster cycle;
- hourly backup cycle (or temporarily reduce the interval only in a local test copy);
- SIGINT/SIGTERM graceful shutdown.

## 7. Most likely local runtime problems and fixes

### `ModuleNotFoundError: aiogram`
Activate the venv and run `pip install -r requirements.txt`.

### `RuntimeError: Missing required environment variable`
Create `.env` beside the `otp_forwarder/` package and fill all required variables. The loader resolves `.env` relative to the package directory.

### Telegram `Unauthorized` / invalid token
Check `BOT_TOKEN` and make sure the bot token is current.

### Bot starts but no OTP arrives
Check the endpoint reachability, API key/token/cookie, group registration, and scanner logs. The legacy endpoint values have not been live-verified by the build environment.

### Telegram bot cannot send to a group
Add the bot to the group, grant the permissions needed to post/pin messages, then run `/addgroup` inside that group.

### Rich Message method/type error
Verify the installed aiogram version satisfies `aiogram>=3.31,<4`. If your environment resolves a different compatible release, report the exact traceback before changing APIs.

### `ruff` or `mypy` reports issues
Do not silently ignore them. Capture the exact command output and traceback/error lines and send them back for a targeted patch.

### `pytest` fails
Run the failing test alone, for example:

```bash
pytest -v otp_forwarder/tests/test_otp.py
```

Then send the complete failure output.
