"""Aiogram 3.x handlers using Telegram Rich Messages."""
from __future__ import annotations

import asyncio
import html
import logging
from datetime import datetime

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from .. import core
from .menus import (
    backup_keyboard, backup_message, groups_keyboard, groups_message, main_keyboard,
    main_message, search_keyboard, search_message, settings_keyboard, settings_message,
    stats_keyboard, stats_message, traffic_keyboard, traffic_message,
)

logger = logging.getLogger(__name__)
router = Router(name="otp-forwarder")


def _uptime() -> str:
    return str(datetime.now() - core.START_TIME).split(".")[0]


async def send_rich(target: Message, rich_message, reply_markup=None):
    """Send a Bot API Rich Message through aiogram's sendRichMessage."""
    return await target.answer_rich(rich_message, reply_markup=reply_markup)


async def replace_rich(callback: CallbackQuery, rich_message, reply_markup=None):
    """Replace the current rich message.

    Bot API exposes sendRichMessage but not editRichMessage, so a rich-message
    navigation action deletes the previous message and sends a fresh one.
    """
    message = callback.message
    if message is not None:
        try:
            await message.delete()
        except TelegramBadRequest:
            pass
        return await message.bot.send_rich_message(
            chat_id=message.chat.id,
            rich_message=rich_message,
            reply_markup=reply_markup,
        )
    return None


@router.message(Command("start"))
async def start(message: Message) -> None:
    await send_rich(message, main_message(), main_keyboard())


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    await send_rich(message, main_message(), main_keyboard())


@router.message(Command("stats"))
async def stats_command(message: Message) -> None:
    await send_rich(message, stats_message(), stats_keyboard())


@router.message(Command("traffic"))
async def traffic_command(message: Message) -> None:
    rich = traffic_message()
    sent = await send_rich(message, rich, traffic_keyboard())
    try:
        await message.bot.pin_chat_message(message.chat.id, sent.message_id, disable_notification=True)
    except Exception as exc:
        logger.warning("Failed to pin manual traffic message: %s", exc)


@router.message(Command("search"))
async def search_command(message: Message) -> None:
    args = (message.text or "").split(maxsplit=1)
    if len(args) < 2:
        await send_rich(message, search_message(), search_keyboard())
        return
    service = args[1].strip()
    try:
        results = core.db.search_by_service(service, limit=30)
        if not results:
            from aiogram.types import InputRichMessage, InputRichBlockSectionHeading, InputRichBlockParagraph
            rich = InputRichMessage(blocks=[InputRichBlockSectionHeading(text="🔍 NO RECORDS FOUND", size=1), InputRichBlockParagraph(text=f"Query: {service}")])
            await send_rich(message, rich, search_keyboard())
            return
        from aiogram.types import InputRichMessage, InputRichBlockSectionHeading, InputRichBlockParagraph, InputRichBlockTable, RichBlockTableCell
        rows = []
        for r in results[:15]:
            otp = r.get("otp_code") or core.extract_otp(r.get("text", "")) or "N/A"
            rows.append([core.mask_number(r.get("phone", "")), otp, r.get("service", "")])
        cells = [[RichBlockTableCell(align="left", valign="middle", text=v, is_header=True) for v in ["Number", "OTP", "Service"]]]
        cells += [[RichBlockTableCell(align="left", valign="middle", text=str(v)) for v in row] for row in rows]
        rich = InputRichMessage(blocks=[
            InputRichBlockSectionHeading(text="🔍 SEARCH RESULTS", size=1),
            InputRichBlockParagraph(text=f"Query: {service} · Found: {len(results)}"),
            InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True, is_compact=True),
        ])
        await send_rich(message, rich, search_keyboard())
    except Exception as exc:
        logger.exception("Search command failed")
        await message.answer(f"❌ Search error: {html.escape(str(exc))}")


@router.message(Command("status"))
async def status_command(message: Message) -> None:
    stats = core.db.get_stats()
    from aiogram.types import InputRichMessage, InputRichBlockSectionHeading, InputRichBlockTable, RichBlockTableCell
    rows = [["Status", "Active & Operational"], ["Uptime", _uptime()], ["Database", f"{stats['total']:,}"], ["Groups", str(len(core.db.get_groups()))], ["Scan Interval", f"{core.SCAN_INTERVAL}s"], ["Seen Cache", str(len(core.SEEN_OTPS))]]
    cells = [[RichBlockTableCell(align="left", valign="middle", text=v, is_header=True) for v in ["Metric", "Value"]]]
    cells += [[RichBlockTableCell(align="left", valign="middle", text=v) for v in row] for row in rows]
    await send_rich(message, InputRichMessage(blocks=[InputRichBlockSectionHeading(text="⚙️ ENGINE DIAGNOSTICS", size=1), InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True)]))


@router.message(Command("clearcache"))
async def clear_cache_command(message: Message) -> None:
    core.SEEN_OTPS.clear()
    core._service_cache.clear()
    core._country_cache.clear()
    from aiogram.types import InputRichMessage, InputRichBlockSectionHeading, InputRichBlockParagraph
    await send_rich(message, InputRichMessage(blocks=[InputRichBlockSectionHeading(text="🗑️ MEMORY FLUSH COMPLETED", size=1), InputRichBlockParagraph(text="Internal cache and tracking registries cleared.")]))


@router.message(Command("groups"))
async def listgroups_command(message: Message) -> None:
    await send_rich(message, groups_message(), groups_keyboard())


@router.message(Command("addgroup"))
async def addgroup_command(message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        await message.answer("❌ This command must be executed inside a Telegram Group!")
        return
    ok = core.db.add_group(message.chat.id, message.chat.title or "Telegram Group")
    await message.answer("✅ Group registered." if ok else "❌ Failed to add group.")


@router.message(Command("removegroup"))
async def removegroup_command(message: Message) -> None:
    if message.chat.type not in ("group", "supergroup"):
        await message.answer("❌ This command must be executed inside a Telegram Group!")
        return
    ok = core.db.remove_group(message.chat.id)
    await message.answer("🗑️ Group removed." if ok else "❌ Failed to remove group.")


@router.message(Command("backup"))
async def backup_command(message: Message) -> None:
    status = await send_rich(message, backup_message(), backup_keyboard())
    ok = await core.create_and_send_backup(message.bot, message.chat.id)
    if not ok:
        await message.answer("❌ Backup generation failed.")


@router.message(Command("resend"))
async def resend_command(message: Message) -> None:
    status = await message.answer("🚀 Initiating resend batch…")
    try:
        entries = await core.fetch_all_resend_sources()
        if not entries:
            await status.edit_text("❌ No data available")
            return
        args = (message.text or "").split()
        arg = args[1].lower() if len(args) > 1 else "5"
        target_entries = entries if arg == "all" else entries[:int(arg)] if arg.isdigit() else entries[:5]
        sent = 0
        sem = asyncio.Semaphore(10)
        async def bounded(entry):
            nonlocal sent
            async with sem:
                otp = entry.get("otp_code") or core.extract_otp(entry.get("text", ""))
                if otp:
                    entry["otp_code"] = otp
                    if not entry.get("country") or entry.get("country") == "Unknown":
                        country, flag, iso, carrier_name = core.get_country_info(entry.get("phone", ""))
                        entry.update(country=country, country_code=iso, carrier=carrier_name, flag=flag)
                    if entry.get("service") in ("Unknown", "SMS"):
                        detected = core.detect_service(entry.get("text", ""))
                        if detected != "Unknown": entry["service"] = detected
                if await core.send_to_group(message.bot, entry): sent += 1
                await asyncio.sleep(0.2)
        await asyncio.gather(*(bounded(e) for e in target_entries))
        await message.answer(f"✅ Resend completed: {sent} / {len(target_entries)}")
    except Exception as exc:
        logger.exception("Resend command error")
        await message.answer(f"❌ Error during resend: {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("menu:"))
async def menu_callbacks(callback: CallbackQuery) -> None:
    target = callback.data.split(":", 1)[1]
    await callback.answer()
    if target == "main":
        await replace_rich(callback, main_message(), main_keyboard())
    elif target == "stats":
        await replace_rich(callback, stats_message(), stats_keyboard())
    elif target == "traffic":
        await replace_rich(callback, traffic_message(), traffic_keyboard())
    elif target == "groups":
        await replace_rich(callback, groups_message(), groups_keyboard())
    elif target == "settings":
        if callback.from_user.id != core.OWNER_ID:
            await callback.answer("Owner only", show_alert=True)
            return
        await replace_rich(callback, settings_message(True), settings_keyboard())
    elif target == "search":
        await replace_rich(callback, search_message(), search_keyboard())
    elif target == "backup":
        await replace_rich(callback, backup_message(), backup_keyboard())
    else:
        await replace_rich(callback, main_message(), main_keyboard())


@router.callback_query(F.data.startswith("action:"))
async def action_callbacks(callback: CallbackQuery) -> None:
    action = callback.data.split(":", 1)[1]
    await callback.answer()
    if action == "refresh_stats":
        await replace_rich(callback, stats_message(), stats_keyboard())
    elif action == "refresh_traffic":
        await replace_rich(callback, traffic_message(), traffic_keyboard())
    elif action == "pin_traffic":
        rich = traffic_message()
        sent = await callback.message.bot.send_rich_message(chat_id=callback.message.chat.id, rich_message=rich, reply_markup=traffic_keyboard())
        try:
            await callback.message.bot.pin_chat_message(callback.message.chat.id, sent.message_id, disable_notification=True)
        except Exception as exc:
            logger.warning("Pin traffic failed: %s", exc)
    elif action == "refresh_groups":
        await replace_rich(callback, groups_message(), groups_keyboard())
    elif action == "refresh_settings":
        if callback.from_user.id != core.OWNER_ID:
            await callback.answer("Owner only", show_alert=True)
            return
        await replace_rich(callback, settings_message(True), settings_keyboard())
    elif action == "create_backup":
        await core.create_and_send_backup(callback.message.bot, callback.message.chat.id)
    elif action in ("add_group", "remove_group"):
        await callback.answer("Use /addgroup or /removegroup inside the target group.", show_alert=True)
    else:
        await callback.answer("Unknown action", show_alert=True)
