"""Legacy text formatters kept for Stage 2 compatibility."""
from ..core import format_otp_message, format_traffic_message
__all__ = ["format_otp_message", "format_traffic_message"]
