# OTP Forwarder — Aiogram 3.x

This project is the staged migration of the original OTP Forwarder from `python-telegram-bot` to aiogram 3.x. The original source is preserved as `otp_forwarder_copybutton.py.bak`, and the SQLite database is preserved as `otp_forwarder.db.bak`.

## Current migration status

- Stage 1: audit, modular scaffold and environment configuration — complete.
- Stage 2: Telegram transport migration to aiogram — complete.
- Stage 3: Rich Message UI — complete.
- Stage 4: async fetchers, typed models, retry/cache and SQLite modernization — complete.
- Stage 5: final runtime validation, documentation and release packaging — next.

## Install

```bash
cd otp_forwarder
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Fill `.env` with your own credentials. Never commit `.env` or distribute the `.bak` source without reviewing/removing secrets.

Run:

```bash
python -m otp_forwarder.main
```

## Commands

`/start` `/help` `/stats` `/traffic` `/search <service>` `/status` `/backup` `/addgroup` `/removegroup` `/groups` `/clearcache` `/resend [count|all]`

## Architecture

```text
otp_forwarder/
├── main.py
├── config.py
├── database.py
├── fetchers/
├── utils/
├── bot/
├── tasks/
├── tests/
├── .env.example
└── requirements.txt
```

## Stage 4 notes

Network sources are fetched concurrently through one reusable `httpx.AsyncClient` per fetch cycle. Transient timeout/network/protocol failures receive bounded exponential retry. SQLite uses WAL and foreign-key enforcement per connection while retaining the existing schema.

The next stage is the final integration/runtime validation pass. It should be run on the deployment host after installing the pinned requirements and supplying valid environment values.
