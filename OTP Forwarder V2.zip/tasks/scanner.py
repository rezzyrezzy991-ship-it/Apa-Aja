"""Scanner task export."""
from ..core import run_scanner

__all__ = ["run_scanner"]
