"""Legacy API async fetcher."""
from __future__ import annotations
from datetime import datetime
from typing import Any
import httpx
from .http import request_json

async def fetch_legacy(client: httpx.AsyncClient, *, url: str, token: str, timeout: float) -> list[dict[str, Any]]:
    if not url:
        return []
    try:
        data = await request_json(client, "GET", url, timeout=timeout, params={"token": token, "records": ""})
        if not isinstance(data, list):
            return []
        result = []
        for item in data:
            if len(item) >= 3:
                result.append({"phone": item[1] if len(item) > 1 else "", "text": item[2].replace("\n", " ") if len(item) > 2 else "", "service": item[0] if len(item) > 0 else "Unknown", "source": "📜 Legacy", "timestamp": item[3] if len(item) > 3 else datetime.now().isoformat()})
        return result
    except Exception:
        return []
