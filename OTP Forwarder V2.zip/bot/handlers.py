"""Telegram command and callback handlers for aiogram 3.x."""
from __future__ import annotations

import asyncio
import html
import logging
from datetime import datetime

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InputRichBlockParagraph, InputRichBlockSectionHeading, InputRichBlockTable, InputRichMessage, Message, RichBlockTableCell

from .. import core
from .menus import (
    backup_keyboard,
    backup_message,
    groups_keyboard,
    groups_message,
    main_keyboard,
    main_message,
    search_keyboard,
    search_message,
    settings_keyboard,
    settings_message,
    stats_keyboard,
    stats_message,
    traffic_keyboard,
    traffic_message,
)

logger = logging.getLogger(__name__)
router = Router(name="otp-forwarder")


def _uptime() -> str:
    return str(datetime.now() - core.START_TIME).split(".")[0]


async def send_rich(message: Message, rich_message: InputRichMessage, reply_markup=None) -> Message:
    """Send a native Rich Message through aiogram."""
    return await message.answer_rich(rich_message, reply_markup=reply_markup)


async def replace_rich(callback: CallbackQuery, rich_message: InputRichMessage, reply_markup=None) -> None:
    """Edit an existing Telegram message with new rich content."""
    message = callback.message
    if message is None:
        return
    try:
        await message.edit_text(text=None, rich_message=rich_message, reply_markup=reply_markup)
    except TelegramBadRequest as exc:
        logger.error("Rich message edit failed: %s", exc, exc_info=True)
        sent = await message.bot.send_rich_message(
            chat_id=message.chat.id,
            rich_message=rich_message,
            reply_markup=reply_markup,
        )
        try:
            await message.delete()
        except TelegramBadRequest as delete_exc:
            logger.error("Fallback old-message deletion failed: %s", delete_exc, exc_info=True)
        logger.info("Rich message fallback sent as message %s", sent.message_id)


@router.message(Command("start"))
async def start_command(message: Message) -> None:
    await send_rich(message, main_message(), main_keyboard())


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    await send_rich(message, main_message(), main_keyboard())


@router.message(Command("stats"))
async def stats_command(message: Message) -> None:
    await send_rich(message, stats_message(), stats_keyboard())


@router.message(Command("traffic"))
async def traffic_command(message: Message) -> None:
    sent = await send_rich(message, traffic_message(), traffic_keyboard())
    try:
        await message.bot.pin_chat_message(message.chat.id, sent.message_id, disable_notification=True)
    except Exception as exc:
        logger.error("Manual traffic pin failed: %s", exc, exc_info=True)


@router.message(Command("search"))
async def search_command(message: Message) -> None:
    args = (message.text or "").split(maxsplit=1)
    if len(args) < 2:
        await send_rich(message, search_message(), search_keyboard())
        return
    service = args[1].strip()
    results = core.db.search_by_service(service, limit=30)
    if not results:
        rich = InputRichMessage(
            blocks=[
                InputRichBlockSectionHeading(text="🔍 NO RECORDS FOUND", size=1),
                InputRichBlockParagraph(text=f"Query: {service}"),
            ]
        )
        await send_rich(message, rich, search_keyboard())
        return
    rows = []
    for result in results[:15]:
        otp = result.get("otp_code") or core.extract_otp(str(result.get("text", ""))) or "N/A"
        rows.append([core.mask_number(str(result.get("phone", ""))), otp, result.get("service", "")])
    cells = [
        [RichBlockTableCell(align="left", valign="middle", text=header, is_header=True) for header in ["Number", "OTP", "Service"]]
    ]
    cells.extend(
        [RichBlockTableCell(align="left", valign="middle", text=str(value)) for value in row]
        for row in rows
    )
    rich = InputRichMessage(
        blocks=[
            InputRichBlockSectionHeading(text="🔍 SEARCH RESULTS", size=1),
            InputRichBlockParagraph(text=f"Query: {service} · Found: {len(results)}"),
            InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True, is_compact=True),
        ]
    )
    await send_rich(message, rich, search_keyboard())


@router.message(Command("status"))
async def status_command(message: Message) -> None:
    stats = core.db.get_stats()
    rows = [
        ["Status", "Active & Operational"],
        ["Uptime", _uptime()],
        ["Database", f"{stats['total']:,}"],
        ["Groups", str(len(core.db.get_groups()))],
        ["Scan Interval", f"{core.SCAN_INTERVAL}s"],
        ["Seen Cache", str(len(core.SEEN_OTPS))],
    ]
    cells = [[RichBlockTableCell(align="left", valign="middle", text="Metric", is_header=True), RichBlockTableCell(align="left", valign="middle", text="Value", is_header=True)]]
    cells.extend([RichBlockTableCell(align="left", valign="middle", text=str(value)) for value in row] for row in rows)
    rich = InputRichMessage(
        blocks=[
            InputRichBlockSectionHeading(text="⚙️ ENGINE DIAGNOSTICS", size=1),
            InputRichBlockTable(cells=cells, is_bordered=True, is_striped=True),
        ]
    )
    await send_rich(message, rich)


@router.message(Command("clearcache"))
async def clear_cache_command(message: Message) -> None:
    core.SEEN_OTPS.clear()
    from ..utils.country import _country_cache
    from ..utils.otp import _service_cache

    _service_cache.clear()
    _country_cache.clear()
    rich = InputRichMessage(
        blocks=[
            InputRichBlockSectionHeading(text="🗑️ MEMORY FLUSH COMPLETED", size=1),
            InputRichBlockParagraph(text="Runtime tracking and metadata caches were cleared."),
        ]
    )
    await send_rich(message, rich)


@router.message(Command("groups"))
async def listgroups_command(message: Message) -> None:
    await send_rich(message, groups_message(), groups_keyboard())


@router.message(Command("addgroup"))
async def addgroup_command(message: Message) -> None:
    if message.chat.type not in {"group", "supergroup"}:
        await message.answer("❌ This command must be executed inside a Telegram Group.")
        return
    ok = core.db.add_group(message.chat.id, message.chat.title or "Telegram Group")
    await message.answer("✅ Group registered." if ok else "❌ Failed to add group.")


@router.message(Command("removegroup"))
async def removegroup_command(message: Message) -> None:
    if message.chat.type not in {"group", "supergroup"}:
        await message.answer("❌ This command must be executed inside a Telegram Group.")
        return
    ok = core.db.remove_group(message.chat.id)
    await message.answer("🗑️ Group removed." if ok else "❌ Group was not registered.")


@router.message(Command("backup"))
async def backup_command(message: Message) -> None:
    if message.from_user is None or message.from_user.id != core.OWNER_ID:
        await message.answer("❌ Owner only.")
        return
    await send_rich(message, backup_message(), backup_keyboard())
    ok = await core.create_and_send_backup(message.bot, message.chat.id)
    if not ok:
        await message.answer("❌ Backup generation failed.")


@router.message(Command("resend"))
async def resend_command(message: Message) -> None:
    status = await message.answer("🚀 Initiating resend batch…")
    try:
        entries = await core.fetch_all_resend_sources()
        if not entries:
            await status.edit_text("❌ No data available")
            return
        args = (message.text or "").split()
        argument = args[1].lower() if len(args) > 1 else "5"
        target_entries = entries if argument == "all" else entries[: int(argument)] if argument.isdigit() else entries[:5]
        semaphore = asyncio.Semaphore(10)
        sent = 0

        async def bounded(entry: dict[str, object]) -> None:
            nonlocal sent
            async with semaphore:
                otp = str(entry.get("otp_code") or core.extract_otp(str(entry.get("text", ""))) or "")
                if otp:
                    entry["otp_code"] = otp
                    country, flag, iso, carrier = core.get_country_info(str(entry.get("phone", "")))
                    entry.update(country=country, flag=flag, country_code=iso, carrier=carrier)
                    if entry.get("service") in {"Unknown", "SMS"}:
                        detected = core.detect_service(str(entry.get("text", "")))
                        if detected != "Unknown":
                            entry["service"] = detected
                if await core.send_to_group(message.bot, entry):
                    sent += 1
                await asyncio.sleep(0.2)

        await asyncio.gather(*(bounded(entry) for entry in target_entries))
        await status.edit_text(f"✅ Resend completed: {sent} / {len(target_entries)}")
    except Exception as exc:
        logger.exception("Resend command failed")
        await status.edit_text(f"❌ Error during resend: {html.escape(str(exc))}")


@router.callback_query(F.data.startswith("menu:"))
async def menu_callbacks(callback: CallbackQuery) -> None:
    data = callback.data or "menu:main"
    target = data.split(":", 1)[1]
    if target == "main":
        await replace_rich(callback, main_message(), main_keyboard())
    elif target == "stats":
        await replace_rich(callback, stats_message(), stats_keyboard())
    elif target == "traffic":
        await replace_rich(callback, traffic_message(), traffic_keyboard())
    elif target == "groups":
        await replace_rich(callback, groups_message(), groups_keyboard())
    elif target == "settings":
        if callback.from_user.id != core.OWNER_ID:
            await callback.answer("Owner only", show_alert=True)
            return
        await replace_rich(callback, settings_message(True), settings_keyboard())
    elif target == "search":
        await replace_rich(callback, search_message(), search_keyboard())
    elif target == "backup":
        await replace_rich(callback, backup_message(), backup_keyboard())
    else:
        await callback.answer("Unknown menu", show_alert=True)
        return
    await callback.answer()


@router.callback_query(F.data.startswith("action:"))
async def action_callbacks(callback: CallbackQuery) -> None:
    data = callback.data or "action:unknown"
    action = data.split(":", 1)[1]
    if action == "refresh_stats":
        await replace_rich(callback, stats_message(), stats_keyboard())
    elif action == "refresh_traffic":
        await replace_rich(callback, traffic_message(), traffic_keyboard())
    elif action == "pin_traffic":
        sent = await callback.message.bot.send_rich_message(
            chat_id=callback.message.chat.id,
            rich_message=traffic_message(),
            reply_markup=traffic_keyboard(),
        )
        try:
            await callback.message.bot.pin_chat_message(callback.message.chat.id, sent.message_id, disable_notification=True)
        except Exception as exc:
            logger.error("Pin traffic callback failed: %s", exc, exc_info=True)
    elif action == "refresh_groups":
        await replace_rich(callback, groups_message(), groups_keyboard())
    elif action == "refresh_settings":
        if callback.from_user.id != core.OWNER_ID:
            await callback.answer("Owner only", show_alert=True)
            return
        await replace_rich(callback, settings_message(True), settings_keyboard())
    elif action == "create_backup":
        if callback.from_user.id != core.OWNER_ID:
            await callback.answer("Owner only", show_alert=True)
            return
        await core.create_and_send_backup(callback.message.bot, callback.message.chat.id)
    elif action == "add_group":
        await _group_action(callback, add=True)
        return
    elif action == "remove_group":
        await _group_action(callback, add=False)
        return
    else:
        await callback.answer("Unknown action", show_alert=True)
        return
    await callback.answer()


async def _group_action(callback: CallbackQuery, *, add: bool) -> None:
    """Apply group add/remove from the menu when the current chat is a group."""
    if callback.message.chat.type not in {"group", "supergroup"}:
        await callback.answer("Open this menu inside the target group to change its registration.", show_alert=True)
        return
    if add:
        ok = core.db.add_group(callback.message.chat.id, callback.message.chat.title or "Telegram Group")
        await callback.answer("Group added" if ok else "Group add failed", show_alert=not ok)
    else:
        ok = core.db.remove_group(callback.message.chat.id)
        await callback.answer("Group removed" if ok else "Group was not registered", show_alert=not ok)


@router.callback_query(F.data.startswith("otp:"))
async def otp_callbacks(callback: CallbackQuery) -> None:
    data = callback.data or "otp:unknown"
    action = data.split(":", 1)[1]
    if action == "detail":
        await callback.answer("OTP details are shown in the rich message table.", show_alert=True)
    elif action == "methods":
        await callback.answer("Use the Methods button on the OTP message for the configured guide.", show_alert=True)
    else:
        await callback.answer("Unknown OTP action", show_alert=True)


@router.callback_query(F.data == "noop")
async def noop_callback(callback: CallbackQuery) -> None:
    await callback.answer("OTP is ready to copy.")
