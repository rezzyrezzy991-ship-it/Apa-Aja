"""NumberPanel API fetcher."""
from __future__ import annotations
from datetime import datetime
from typing import Any
import httpx
from .http import request_json

async def fetch_numberpanel(client: httpx.AsyncClient, *, base_url: str, api_key: str, timeout: float) -> list[dict[str, Any]]:
    sources = [
        ("🌟 Panel", f"{base_url.rstrip('/')}/api/otp?count=500", None),
        ("🔥 Key", f"{base_url.rstrip('/')}/api/otp?count=500", api_key),
        ("📱 MyOTP", f"{base_url.rstrip('/')}/api/my_otps?limit=200", api_key),
        ("⚡ Latest", f"{base_url.rstrip('/')}/api/latest_otp", api_key),
    ]
    entries: list[dict[str, Any]] = []
    for source, url, auth in sources:
        try:
            headers = {"Authorization": f"Bearer {auth}"} if auth else None
            data = await request_json(client, "GET", url, timeout=timeout, headers=headers)
            if isinstance(data, list):
                for item in data:
                    if len(item) >= 3:
                        phone, text = item[1], item[2]
                        if phone and text:
                            entries.append({"phone": phone, "text": text, "service": item[0] if len(item) else "Unknown", "source": source, "timestamp": item[3] if len(item) > 3 else datetime.now().isoformat()})
            elif isinstance(data, dict) and data.get("success"):
                if "otps" in data:
                    for item in data["otps"]:
                        if isinstance(item, dict):
                            phone = item.get("number") or item.get("phone") or ""
                            text = item.get("message") or item.get("text") or item.get("content") or ""
                            if phone and text:
                                entries.append({"phone": phone, "text": text, "service": item.get("service") or item.get("app") or "Unknown", "source": source, "timestamp": item.get("time") or item.get("created_at") or datetime.now().isoformat()})
                elif data.get("has_otp") and data.get("otp_code"):
                    entries.append({"phone": "", "text": f"OTP: {data['otp_code']}", "service": "OTP", "source": source, "timestamp": datetime.now().isoformat()})
        except Exception:
            continue
    return entries
