"""Legacy API asynchronous fetcher."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx

from .http import request_json


async def fetch_legacy(
    client: httpx.AsyncClient,
    *,
    url: str,
    token: str,
    timeout: float,
) -> list[dict[str, Any]]:
    if not url:
        return []
    try:
        data = await request_json(
            client,
            "GET",
            url,
            timeout=timeout,
            params={"token": token, "records": ""},
        )
        if not isinstance(data, list):
            return []
        result: list[dict[str, Any]] = []
        for item in data:
            if not isinstance(item, (list, tuple)) or len(item) < 3:
                continue
            result.append(
                {
                    "phone": str(item[1]),
                    "text": str(item[2]).replace("\n", " "),
                    "service": str(item[0]),
                    "source": "📜 Legacy",
                    "timestamp": item[3] if len(item) > 3 else datetime.now().isoformat(),
                }
            )
        return result
    except Exception as exc:
        import logging

        logging.getLogger(__name__).error("Legacy fetch failed: %s", exc, exc_info=True)
        return []
