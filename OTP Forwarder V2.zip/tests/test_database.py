import sqlite3
from pathlib import Path
from otp_forwarder.database import Database

def test_database_wal_and_foreign_keys(tmp_path: Path):
    db = Database(str(tmp_path / "test.db"))
    with db._get_conn() as conn:
        assert conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        assert conn.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal"
